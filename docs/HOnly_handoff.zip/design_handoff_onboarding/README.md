# HOnly — Onboarding Design Handoff

**Version:** 1.0 · June 2026
**Status:** Frozen design skeleton — build from this, do not edit the existing front end.
**Platform:** Mobile-first (iOS/Android web or native). Design frame **404 × 884 @ 1×**.

---

## 0. What this package is

This is a **developer handoff** for the HOnly onboarding experience. The files here are
**design references** — HTML/CSS/JSX prototypes that show the intended look, copy, and
behavior precisely. They are **not** meant to be shipped as-is. Your job is to **recreate
these designs in your target codebase** (React Native, SwiftUI, Flutter, a React web app,
etc.) using that codebase's own component library, navigation, and state patterns.

The prototype is **high-fidelity**: every color, font, size, radius, shadow, and string in
this package is final and should be reproduced exactly. Where this package says a value
(e.g. `--coral: #E8654A`, `border-radius: 18px`), treat it as the spec.

> **Design freeze.** The onboarding structure, screen order, navigation model, card/grid
> structure, and the safety/flirt/privacy entry points are **frozen**. See
> [`docs/developer-notes.md`](docs/developer-notes.md) for exactly what must not change and
> what you are free to implement however your stack prefers.

---

## 1. Package map

```
design_handoff_onboarding/
├── README.md                      ← you are here
│
├── docs/
│   ├── screen-map.md              ← every screen: ID, purpose, prev/next, button actions, logic
│   ├── design-system.md           ← colors, type, spacing, buttons, cards, inputs, layout rules
│   ├── components.md              ← reusable component inventory + props/states
│   └── developer-notes.md         ← what is FROZEN vs. free; data model; safety rules
│
├── screens/                       ← one spec file per screen (built screens + planned stubs)
│   ├── 00-welcome.md … 14-discover.md   (built — full specs)
│   └── 90-discovery-grid.md … 96-empty-states.md  (PLANNED — not yet designed; spec stubs)
│
├── src/                           ← organized, runnable source of the built prototype
│   ├── index.html                 ← open this in a browser to run the whole flow
│   ├── styles/
│   │   └── onboarding.css          ← the complete design system as CSS (extracted)
│   └── components/
│       ├── data.jsx                ← all option sets + the interest taxonomy + flow definition
│       ├── ui.jsx                  ← primitives: Logo, NavBar, Chip, OptionCard, buttons, …
│       ├── interests.jsx           ← Screen 5 branching engine (inline + bottom-sheet)
│       ├── screens-core.jsx        ← Welcome, Sign in, Age, Name, Intent, Depth, Interests, Flirt
│       ├── screens-extra.jsx       ← Rhythm, Languages, About, Pledge, Done, Discover demo
│       ├── app.jsx                 ← state, navigation, persistence, theme hook, Tweaks
│       ├── tweaks-panel.jsx        ← optional in-prototype controls (NOT shipped)
│       └── image-slot.js           ← drag-drop photo placeholder used on Welcome (NOT shipped)
│
├── exports/
│   ├── png/                        ← every screen as a PNG, in order (00 … 14)
│   └── all-screens.html            ← print-ready, one screen per page → "Save as PDF"
│
└── reference/                      ← original previews, do not build from these directly
    ├── HOnly Onboarding (dark — original preview).html     ← canonical theme (this handoff)
    ├── HOnly Onboarding (light — template preview).html    ← alternate light/cream theme
    └── MOBILE_DESIGN (source template).md                  ← the approved visual template
```

---

## 2. How to run the prototype

Open `src/index.html` in any modern browser (no build step — it uses CDN React + Babel).
The flow is fully clickable. Two helpers exist for review/QA only:

- **Resume:** progress is saved to `localStorage` (`honly_onboarding_v1`). Refreshing keeps
  your place. This is a prototype convenience — your app will use real auth/session state.
- **Jump to any screen (QA):** in the browser console run
  `window.__honlyShow('intent', true)` — the first arg is a screen key (see screen-map),
  the second `true` seeds a rich demo profile so populated screens render fully.

The two intentionally-dark **Welcome** and **Sign in** screens use a photo placeholder
(`image-slot.js`); drag any image onto the hero to preview it. In production this is the
user's chosen hero/brand image.

---

## 3. Two themes

There are two approved visual themes. **The dark theme is canonical for this handoff** and
is what `src/` and `exports/` reflect.

| | Dark (canonical) | Light (alternate) |
|---|---|---|
| Surface | Navy `#151D27` | Cream `#F5EFE6` |
| Display font | Bricolage Grotesque | Space Grotesk |
| Body font | Plus Jakarta Sans | Inter |
| Progress | Bar | Dots |
| Welcome / Sign in | Dark | **Dark** (kept dark in both) |

Both themes share **identical** structure, copy, components, and logic — only tokens differ.
If you build the light theme, see `reference/MOBILE_DESIGN (source template).md` and the
light preview. `docs/design-system.md` lists both token sets.

---

## 4. Where to start

1. Read `docs/developer-notes.md` — understand what is frozen.
2. Read `docs/screen-map.md` — understand the flow and conditional logic.
3. Build atoms from `docs/components.md` + `docs/design-system.md`.
4. Assemble screens using the per-screen specs in `screens/`.
5. Use `exports/png/` and `src/index.html` as your pixel reference.

Questions on intent or copy should come back to the design owner — **do not silently
substitute** different wording, ordering, or safety affordances.
