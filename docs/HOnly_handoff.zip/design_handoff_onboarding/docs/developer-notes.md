# HOnly — Developer Notes (Freeze Contract & Data Model)

Read this first. It defines what is **frozen** (the design skeleton you must preserve) versus
what is **yours to implement** however your codebase prefers.

---

## 1. Frozen — do NOT change

These are product/design decisions. Reproduce them exactly; route any change request back to
the design owner.

### Onboarding structure & order
- The screen sequence and the split between **required** and **optional** steps is frozen:
  `welcome → (age → name → intent → depth → interests → flirt) → [rhythm? → langs? → about?] →
  pledge → done → discover`. Optional steps keep a **Skip** action.
- Gating rules are frozen: age 18+ is a hard gate; name required; intent ≥1; depth required;
  **interests ≥3**; flirt required; pledge required. Don't loosen or reorder.

### Main navigation & screen hierarchy
- Two entry paths from Welcome — **Join** (new) and **Sign in** (returning) — are frozen.
- The onboarding is a **linear stepper** with a back affordance and a 10-step progress
  indicator. Don't turn it into tabs, a single long form, or a carousel.
- **Welcome (00) and Sign in (01) are intentionally dark** in both themes. Keep them dark.

### Card / grid / chip structure
- The interest model is frozen: **topic chips → optional inline sub-topic panel**, parent
  counts alone, sub-topics optional + multi-select, **one panel open at a time**, inline
  treatment is the shipped one.
- Sensitive topics render **teal**, not coral. The `+N` count badge and chevron affordance stay.
- Option cards, the profile-preview card, and the match card keep their structure (emoji +
  text + mark; header + chips).

### Chat entry point
- The **only** entry into a conversation is the **"Start conversation"** CTA on a match /
  profile card (Screen 14, and the planned profile card 91). There is no cold-DM/inbox-blast
  entry. Keep conversation initiation gated behind a match view.

### Safety / reporting / privacy entry points
- The **flirt boundary** (Screen 07) is a required step and is **mutual-only, reversible, never
  sexualised**; "Keep it platonic" is a **protected hard signal**. The **Discover flirt
  indicator** must reflect it (coral if both open/mutual, teal platonic otherwise).
- **Privacy defaults are frozen:** location **off by default**; off-limits list **private**;
  the private "Something I'm carrying" topic is **`private_matching_only`** and never shown
  publicly without explicit later opt-in; avatar is **equal** to a photo (never nudge toward a face).
- The verbatim **safety/privacy copy** (support-resources line on Intent, "only you see this",
  "Private by default…", flirt reassurance) must be preserved. These are trust primitives.
- Report/Block (planned Screen 95) must be reachable from **both** chat and profile overflow —
  keep that affordance when you build those screens.

### Brand
- Logo construction, coral/teal/navy/cream palette, and the dual font pairing are frozen.
- The product positioning line **"This is not a dating app · No pressure"** stays on Welcome.

---

## 2. Yours to implement (not prescribed)

- **Framework & architecture:** rebuild in your stack (React Native / SwiftUI / Flutter / web).
  The prototype's React-on-CDN + `window` globals are a **prototype convenience**, not an
  architecture recommendation.
- **State & persistence:** the prototype uses `localStorage` (`honly_onboarding_v1`) and a flat
  state object. Replace with your real session/auth, API calls, and validation. Server-side
  enforce the gates (age, profanity/impersonation on name, etc.).
- **Auth:** SSO buttons are stubs — wire real Google/Apple/email auth.
- **Animations:** match the spirit (gentle slide/fade, reduced-motion safe); exact easing optional.
- **Status bar:** use the real OS bar; the faux `9:41` bar is prototype chrome.
- **Photo hero:** `image-slot.js` is a drag-drop prototype placeholder — replace with your image
  pipeline. Not shipped.
- **Tweaks panel** (`tweaks-panel.jsx`): a design-review tool (theme/treatment toggles). **Do not
  ship it.**

---

## 3. Data model

### Onboarding state object (prototype `INITIAL`, see `app.jsx`)
```
age18: boolean              // hard gate
name: string                // public display name, ≤24 chars
intent: string[]            // INTENTS ids, ≥1
depth: 'light'|'both'|'deep'
topics: { [topicId]: string[] }   // selected topics → chosen sub-topics (may be [])
flirt: 'open'|'mutual'|'depends'|'platonic'
rhythm: 'quick'|'daily'|'slow' | null
offlimits: string[]         // PRIVATE
langs: { lang: string, role: 'native'|'learning'|'connect' }[]
vibe: VIBES id | null       // drives the profile badge
avatar: emoji | null        // equal to a photo
ageRange, gender: string | null
location: 'none'|'country'|'city'|'tz'   // default 'none' (OFF)
meeting: 'online'|'maybe'|'open' | null
cultures: string[]
pledge: boolean             // required
```

### Option sets & taxonomy
All in `src/components/data.jsx` — `INTENTS, DEPTHS, TAXONOMY, FLIRT, RHYTHM, OFFLIMITS,
LANGUAGES, LANG_ROLES, VIBES, AVATARS, AGES, GENDERS, LOCATION, MEETING, FLOW`. Treat these as
the canonical content. Reproduce labels & emoji exactly.

### Private topic — `private_carrying` ("Something I'm carrying") · **sensitive**
```
Parent key:        private_carrying
Parent label:      "Something I'm carrying"
Subtopics:         optional + multi-select (8 options) — parent alone counts as selected
Default visibility: private_matching_only
Public exposure:   subtopics NEVER public; parent may show as a broad public label ONLY on
                   explicit later opt-in (lives in profile settings, not onboarding)
Tone:              warm, in-control — NOT a therapy/medical intake. No crisis UI.
Custom copy:       panelTitle, panelHelper, privacyNote fields override the generic panel copy
```
This topic is a **conversation preference**, not a health record. Keep the 🤲 (non-medical) icon,
teal sensitive styling, and the privacy note.

---

## 4. Completion scoring
`completion(st)` (in `screens-extra.jsx`) = filled sections / 9, shown as a % on the Done card.
It is a friendly nudge, **never a wall** — users can always proceed and add more later.
