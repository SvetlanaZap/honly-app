# HOnly Onboarding — Screen Map & Flow

Frame: **404 × 884**. Order is **frozen**. Screen keys match `window.__honlyShow('<key>')`
and the `FLOW` array in `src/components/data.jsx`.

## Flow at a glance

```
                ┌─────────────┐
                │ 00 welcome  │
                └──┬───────┬──┘
        Join HOnly │       │ Sign in / SSO
                   ▼       ▼
            ┌──────────┐  ┌──────────────┐
            │ 02 age   │  │ 01 signin    │──(success)──▶ 14 discover (returning user)
            └────┬─────┘  └───┬──────────┘
                 │            │ "Join HOnly" link
                 │◀───────────┘
                 ▼
   03 name ▶ 04 intent ▶ 05 depth ▶ 06 interests ▶ 07 flirt
                 ▶ 08 rhythm* ▶ 09 langs* ▶ 10 about* ▶ 11 pledge ▶ 12 done ▶ 14 discover
   (* = optional step, has a Skip action)
```

The progress indicator counts **10 steps** (`age`→`pledge`); `welcome`, `signin`, `done`,
and `discover` are outside the counter. (`NAV_KEYS` in `app.jsx`.)

---

## Built screens

### 00 · Welcome / Landing
- **ID / key:** `welcome`
- **Purpose:** First impression + the brand promise ("not a dating app"). Split into the
  Join path (new user) and Sign in path (returning user).
- **Previous:** — (entry point)
- **Next:** `age` (primary) or `signin` (secondary)
- **Primary action:** **"Join HOnly — it's free"** → `age`
- **Secondary action:** **"Sign in"** → `signin`
- **Logic:** Intentionally **dark** in both themes. Photo hero is a user/brand image. No nav
  bar / progress here.

### 01 · Sign In (returning user)
- **ID / key:** `signin`
- **Purpose:** Authenticate an existing user.
- **Previous:** `welcome`
- **Next:** `discover` (on success) — prototype routes any of Google / Apple / Sign in there.
- **Primary action:** **"Sign in"** (email/password) → `discover`
- **Secondary actions:** **Continue with Google**, **Continue with Apple** → `discover`;
  **"Forgot password?"** (stub); **"Join HOnly"** link → `age` (enters onboarding).
- **Back:** ← returns to `welcome`.
- **Logic:** Intentionally **dark**. Show/Hide toggles the password field. No progress bar.

### 02 · Age gate
- **ID / key:** `age` · **Eyebrow:** QUICK CHECK · **Step 1/10**
- **Purpose:** Confirm the user is 18+.
- **Previous:** `welcome` (or `signin` via "Join HOnly")
- **Next:** `name`
- **Primary action:** **Continue** → `name`. **Disabled until** the "I'm 18 or older" card is selected.
- **Back:** ← `welcome`.
- **Logic:** Hard gate. `st.age18` must be `true` to proceed.

### 03 · Display name
- **ID / key:** `name` · **Eyebrow:** CREATE ACCOUNT · **Step 2/10**
- **Purpose:** Capture a public display name (need not be real).
- **Previous:** `age` · **Next:** `intent`
- **Primary action:** **Continue** → `intent`. **Disabled until** `st.name` is non-empty (trimmed). `maxLength 24`.
- **Logic:** Enter key submits when valid. Light profanity/impersonation filter noted in copy (not enforced in prototype).

### 04 · Intent — why you're here
- **ID / key:** `intent` · **Eyebrow:** WHY YOU'RE HERE · **Step 3/10**
- **Purpose:** Multi-select reasons for joining. Drives matching.
- **Previous:** `name` · **Next:** `depth`
- **Primary action:** **Continue** → `depth`. **Disabled until ≥1** chip selected (`st.intent.length > 0`).
- **Logic:** Multi-select chips (8 options). "Someone to talk to" copy points to support resources — keep that line.

### 05 · Conversation depth
- **ID / key:** `depth` · **Eyebrow:** YOUR VIBE · **Step 4/10**
- **Purpose:** Single-select tone (Light / Both / Deep).
- **Previous:** `intent` · **Next:** `interests`
- **Primary action:** **Continue** → `interests`. **Disabled until** `st.depth` set.
- **Logic:** Single-select option cards.

### 06 · Interests (branching engine) ★ centerpiece
- **ID / key:** `interests` · **Eyebrow:** WHAT YOU LOVE · **Step 5/10**
- **Purpose:** Pick topics; optionally open a topic to add sub-topics. **Inline expansion**:
  tapping a topic chip selects it and slides a detail panel open directly below it.
- **Previous:** `depth` · **Next:** `flirt`
- **Primary action:** **Continue** → `flirt`. **Disabled until ≥3 topics** selected
  (`Object.keys(st.topics).length >= 3`). Footer shows a live counter.
- **Logic / conditional:**
  - Selecting a topic adds `topics[id] = []`; sub-topics are **optional & multi-select** —
    the parent alone counts as a selected topic.
  - **Sensitive topics** (`sensitive: true`: Spirituality, Family & relationships, Mental
    wellbeing, and the private **"Something I'm carrying"**) render in **teal** instead of coral.
  - **"Something I'm carrying"** (`private_carrying`) uses custom panel copy + a privacy note,
    and `default visibility = private_matching_only`. **Never** show its sub-topics publicly.
    See `screens/06-interests.md` and the dev note in `data.jsx`.
  - Two treatments exist (prototype Tweak): **inline** (default) and **bottom-sheet**. Ship inline.

### 07 · Flirt boundary
- **ID / key:** `flirt` · **Eyebrow:** BOUNDARIES · **Step 6/10**
- **Purpose:** Set the flirting boundary. Core safety primitive.
- **Previous:** `interests` · **Next:** `rhythm`
- **Primary action:** **Continue** → `rhythm`. **Disabled until** `st.flirt` set.
- **Logic:** Single-select (open / mutual / depends / platonic). "Keep it platonic" is a
  **protected hard signal** (teal accent). This value drives the Discover flirt indicator (Screen 14).

### 08 · Rhythm + off-limits *(optional)*
- **ID / key:** `rhythm` · **Eyebrow:** HOW YOU CHAT · **Step 7/10**
- **Previous:** `flirt` · **Next:** `langs`
- **Primary action:** **Save & continue** → `langs`. **Secondary:** **Skip** → `langs`.
- **Logic:** Rhythm single-select; off-limits multi-select chips are **private** ("only you see this").

### 09 · Languages *(optional)*
- **ID / key:** `langs` · **Eyebrow:** LANGUAGES · **Step 8/10**
- **Previous:** `rhythm` · **Next:** `about`
- **Primary action:** **Save & continue** → `about`. **Secondary:** **Skip** → `about`.
- **Logic:** Add languages; each gets a role (native / learning / connect) via a segmented control. Removable rows.

### 10 · About you *(optional)*
- **ID / key:** `about` · **Eyebrow:** ABOUT YOU · **Step 9/10**
- **Previous:** `langs` · **Next:** `pledge`
- **Primary action:** **Finish** → `pledge`. **Secondary:** **Skip for now** → `pledge`.
- **Logic:** Every field optional, each with its own visibility hint. Includes **Today's vibe**
  (drives the badge on the profile preview), avatar/photo (avatar treated equal to photo),
  age range, gender, location (off by default), meeting openness, cultures.

### 11 · Human pledge
- **ID / key:** `pledge` · **Eyebrow:** THE HONLY PART · **Step 10/10**
- **Purpose:** Agree to be a real person acting in good faith.
- **Previous:** `about` · **Next:** `done`
- **Primary action:** **Enter HOnly** → `done`. **Disabled until** `st.pledge` checked.

### 12 · Completion / profile preview
- **ID / key:** `done`
- **Purpose:** Celebrate; show a profile-preview card (avatar, name, age, vibe badge, top
  interests, completion %).
- **Previous:** `pledge` · **Next:** `discover`
- **Primary action:** **"Start exploring →"** → `discover`.
- **Logic:** `completion(st)` computes the % from filled sections. Outside the step counter.

### 14 · Discover — mutual flirt indicator (demo)
- **ID / key:** `discover` *(internal key: `explore`)*
- **Purpose:** Show what a first match feels like and demonstrate the **mutual flirt
  indicator** mechanic that the flirt boundary (Screen 07) drives.
- **Previous:** `done` (new user) or `signin` (returning user)
- **Primary action:** **"💬 Start conversation"** (stub — chat entry point, see planned `92-chat.md`).
- **Secondary:** **"↺ Restart onboarding"** resets state → `welcome` (prototype only).
- **Logic / conditional:** If `st.flirt` is `open` or `mutual`, show the coral "both open to a
  little flirting" indicator; otherwise show the teal **platonic-protected** indicator. This is
  the canonical example of how the boundary travels with the user. Enabled **only if both**
  users opted in.

---

## Planned screens (NOT yet designed — spec stubs only)

These were requested for the handoff but are **not part of the frozen built prototype**. Spec
stubs live in `screens/9x-*.md` describing intended purpose, entry points, and the frozen
anchors they must respect. **Do not invent final visuals** — route them back to design.

| ID | Key | Name | Entry point (frozen) |
|----|-----|------|----------------------|
| 90 | `discovery` | Main grid / discovery | from `done` / `signin` (replaces the single-card demo) |
| 91 | `profile_card` | Profile card / preview | tap a person in discovery |
| 92 | `chat` | Chat screen | **"Start conversation"** on Screen 14 / profile card |
| 93 | `my_profile` | My profile | bottom nav |
| 94 | `settings_safety` | Settings / safety | bottom nav / profile |
| 95 | `report_block` | Report / block | from chat & profile overflow menu |
| 96 | `empty_states` | Empty states | no matches / no messages / offline |
