# HOnly — Design System

All values are taken verbatim from `src/styles/onboarding.css`. The dark theme is canonical;
light-theme overrides are listed where they differ. CSS custom properties are the source of truth.

---

## 1. Colors

### Brand
| Token | Hex | Use |
|-------|-----|-----|
| `--coral` | `#E8654A` | Primary actions, progress fill, selected (non-sensitive) chips, accents, eyebrows |
| `--teal` | `#3CBEA8` | Sensitive/private topics, "platonic" protected signal, success/positive, logo bubble |
| `--badge` | `#E0394B` (dark) / `#FF2D2D` (light) | Notification badge on the logo "o" |

### Dark theme (canonical)
| Token | Hex | Use |
|-------|-----|-----|
| `--bg` | `#151D27` | App background / phone surface |
| `--bg-deep` | `#0E141B` | Page behind the phone, deepest wells |
| `--surface` | `#1F2A36` | Cards, chips, inputs |
| `--surface-2` | `#28333F` | Raised/selected segments, disabled buttons |
| `--text` | `#F3F0E9` | Primary text (cream-white) |
| `--text-2` | `#98A2B0` | Secondary text |
| `--text-3` | `#69737F` | Tertiary / hints / placeholders |
| `--line` | `rgba(255,255,255,.085)` | Hairline borders |
| `--line-2` | `rgba(255,255,255,.16)` | Stronger borders, input outlines |

### Light theme (alternate — from MOBILE_DESIGN template)
| Token | Hex |
|-------|-----|
| `--bg` | `#F5EFE6` (cream) |
| `--bg-deep` | `#ECE4D6` |
| `--surface` | `#FFFFFF` |
| `--surface-2` | `#F1EADF` |
| `--text` | `#1B2532` (navy ink) |
| `--text-2` | `#5A6A7E` |
| `--text-3` | `#8A9BAE` |
| `--line` | `#E8E4DF` |
| `--line-2` | `#DDD6C9` |

> **Note:** Welcome (00) and Sign in (01) stay on the **dark** palette in *both* themes
> (navy `#151D27` sheet). In the light build these two screens scope the dark tokens back on.

### Selected states
- Non-sensitive chip selected: fill `--coral`, text `#fff`.
- **Sensitive** chip selected (`.is-sensitive`): fill `--teal`, text `#fff` (dark) / `#06372e` (light).
- Option card selected: 1.5px `--coral` border + coral ring + soft coral shadow + faint coral tint bg.

---

## 2. Typography

| Role | Dark | Light | Notes |
|------|------|-------|-------|
| Display (`--display`) | **Bricolage Grotesque** | **Space Grotesk** | Titles, logo, step counter, numbers |
| Body (`--body`) | **Plus Jakarta Sans** | **Inter** | All body copy, buttons, inputs, chips |

Loaded via Google Fonts. Weights used: 400/500/600/700/800.

### Type scale (px)
| Element | Size / weight / line-height | Notes |
|---------|------------------------------|-------|
| Hero title (`.w-title`, `.hero-title`) | 30–31 / 800 / 1.1 | letter-spacing −.02em |
| Screen title (`.title`) | 30 / 700 / 1.08 | −.015em, `text-wrap: balance` |
| Sign-in / done title | 28–30 / 800 | |
| Eyebrow (`.eyebrow`) | 12 / 700 / — | uppercase, .16em tracking, `--coral` |
| Subtitle (`.sub`) | 15.5 / 500 / 1.5 | `--text-2`, max-width 34ch |
| Option label | 15.5 / 700 | |
| Option sub | 13 / 500 | `--text-2` |
| Chip | 14.5 / 600 | small variant 13.5 |
| Button | 16 / 700 | |
| Section label (`.seclabel`) | 13.5 / 700 | hint 11.5 / 600 `--text-3` |
| Fine hint (`.finehint`) | 12.5 / 500 / 1.5 | `--text-3` |
| Privacy / helper notes | 11–11.5 / 500–600 / 1.5 | `--text-3`, muted |
| Step counter (`.stepcount`) | 14 / 700 | display font; "/N" in `--text-3` |

### Minimum sizes
Body copy never below **12.5px**. Hit targets (chips, buttons, option rows) ≥ **44px** tall.

---

## 3. Spacing & radii

**Spacing rhythm** (the values that recur): `5, 7, 9, 10, 12, 14, 18, 22, 26px`.
- Screen body padding: `14px 26px 18px`.
- Footer padding: `14px 24px (20–22 + safe-area)`.
- Stack gap between option cards: `10px`. Chip gap: `9px` (10 for large).
- Section label top margin: `24px`.

**Border radius**
| Element | Radius |
|---------|--------|
| Phone surface | 38px (dark) / matches in light |
| Buttons (primary/secondary) | **999px** (pill) |
| Option cards / rows | 18px |
| Inputs (onboarding) | 16px · (light: 14px) |
| Sign-in fields / SSO | 15px · (light: 14px) |
| Chips / counters | 999px (pill) |
| Accordion / inline panel / cards | 16–22px |
| Bottom sheet | 26px top corners (28 in template) |
| Avatar tiles | 14px |

**Shadows**
- `--shadow` (phone): `0 40px 90px -30px rgba(0,0,0,.7)` (dark) / `0 30px 64px -30px rgba(27,37,50,.45)` (light).
- Primary button: `0 14px 30px -10px (coral @70%)`.
- Cards (preview/match): dark `0 18px 40px -26px rgba(0,0,0,.6)`; light `0 6px 22px -10px rgba(27,37,50,.18)`.

---

## 4. Buttons

| Variant | Class | Spec |
|---------|-------|------|
| Primary | `.btn-primary` | Full-width pill, `--coral` bg, white 700 text, coral glow shadow. Hover brightness 1.05; active scale .985. **Disabled:** `--surface-2` bg, `--text-3` text, no shadow. |
| Secondary | `.btn-secondary` | Full-width pill, transparent, 1.5px `--line-2` border, `--text` 700. Hover faint white fill. (Used on Welcome "Sign in".) |
| Ghost | `.btn-ghost` | Text-only, `--text-2` 600, 15px. Hover → `--text`. (Used for Skip.) |
| SSO | `.sso` | Pill 15px radius. `.sso--google` white/dark text; `.sso--apple` `--surface` + border. |
| Footer pairing | `.footer-2` | Ghost (Skip) + Primary side by side; primary flexes to fill. |

Primary buttons are the only coral fill per screen — one primary action each.

---

## 5. Cards & surfaces

- **Option card / row** (`.opt`): flex row, emoji (24px) + text block + check/radio mark
  (24px circle; 8px-radius square for multi-select). 1.5px `--line` border on `--surface`,
  16–17px padding, 18px radius. Selected = coral border + ring.
- **Chip** (`.chip`): inline-flex pill, optional 16px emoji + label, optional `+N` count badge
  (coral) and chevron (for expandable topics). 10×15px padding.
- **Inline expansion panel** (`.inline-panel`): full-width below a selected topic chip;
  `rgba(255,255,255,.035)` fill (light: `#FBF8F2`), 1px `--line`, 16px radius, 13–14px padding;
  title + optional muted helper + "Remove" pill + sub-topic chip cloud + optional privacy note.
- **Preview / match card** (`.preview-card`, `.match-card`): `--surface`, 1.5px `--line`,
  22px radius, soft shadow; header (avatar tile + identity + %) then chips/sections.
- **Bottom sheet** (`.sheet`): rises from bottom, 26px top radius, grip handle, scrim
  `rgba(0,0,0,.55)`. (Alternate interests treatment.)

---

## 6. Inputs

- **Text input** (`.text-input`): full-width, `--surface`, 1.5px `--line-2`, 16px radius,
  17px/600 text. Focus = coral border + 3px coral glow. Optional trailing `✓` when valid.
- **Sign-in field** (`.dark-field`): labeled container (tiny label above value), 15px radius;
  `.is-active` adds coral border + glow. Password has Show/Hide text button.
- **Segmented control** (`.seg`): grid of equal buttons on a faint track; selected button
  raised with `--surface-2` bg + shadow. Used for language roles.
- **Toggle switch** (`.switch`): 46×28px pill; on = `--teal`, knob slides right.
- **"Add your own"** (`.addown-input`): dashed pill input inside sub-topic panels; Enter or
  the coral "Add" button commits.

---

## 7. Iconography

- **No icon library.** Glyphs are **emoji**, used intentionally as the brand's warm visual
  language (topic chips, option cards, vibes, avatars). Reproduce the **exact** emoji in
  `data.jsx`. The private topic uses 🤲 (cupped hands) — deliberately non-medical.
- **Functional icons are inline SVG** (back chevron, accordion chevron, check, status-bar
  signal/wifi/battery, Google/Apple marks). Copy these SVGs from `ui.jsx` / `screens-core.jsx`
  or substitute your app's equivalents at the same sizes.
- **Logo** is pure CSS/markup (`.logo` in `ui.jsx`): coral **H** + teal speech-bubble **o**
  (three dots, first coral) with a red notification **badge**, then white **nly**. Size via
  `font-size` (40px default, `.logo--sm` 30px). Reproduce as an SVG asset in production.

---

## 8. Layout & responsive rules

- **Design frame 404 × 884** (mobile portrait), `@1×`. This is a phone-width experience.
- **Structure per screen:** fixed **status bar** → fixed **nav bar** (back + step counter +
  progress) → **scrollable body** (`.screen-body`, the only scroll region) → fixed **footer**
  (`.screen-footer`) with the primary action. The footer has a gradient fade so content
  scrolls under it.
- **Progress:** dark = thin **bar** (`.progress-fill`, coral, animated width); light = **dots**
  (`.progress-dots`, one per step, current dot elongated). 10 steps counted.
- **Welcome** is the exception: photo hero (≈47% height) + a dark sheet that overlaps upward
  (−34px, 32px top radius). No nav/progress.
- **Safe areas:** footers add `env(safe-area-inset-bottom)`.
- **Motion:** inline panel & bottom sheet slide in (~.26–.28s, `cubic-bezier(.2,.8,.25,1)`).
  Progress width eases .42s. All animation is wrapped by `@media (prefers-reduced-motion:
  reduce)` → near-instant. Entrance opacity must not leave content stuck hidden.
- **Desktop / larger viewports:** the experience is phone-width; center the 404px frame on a
  deep background (as the prototype does). If you ship a responsive web version, keep the
  single-column phone layout and max content width — do **not** reflow onboarding into
  multi-column. Tablet = same centered column.
