# HOnly — Reusable Component Inventory

Build these as atoms/molecules in your codebase. Names map to the prototype's React functions
in `src/components/ui.jsx` (primitives), `interests.jsx`, `screens-core.jsx`, `screens-extra.jsx`.
"Frozen" marks components whose behavior is part of the design freeze.

---

## Primitives (ui.jsx)

### `Logo` — brand wordmark · **frozen**
Coral **H** + teal speech-bubble **o** (3 dots, first coral) + red notification badge + white **nly**.
Props: `small` (30px vs 40px). Production: ship as an SVG. Used on Welcome & Sign in.

### `StatusBar`
Faux iOS status bar: `9:41` + signal / wifi / battery SVGs. Prototype chrome — replace with the
real OS status bar in native, or keep as a mock in web.

### `NavBar` — onboarding progress header · **frozen (structure)**
Back chevron (`onBack`, hidden when `!canBack`) + step counter `n/N` + progress indicator.
Props: `step`, `total`, `canBack`, `dots` (bar vs dots). One per onboarding step screen.

### `Eyebrow`
Uppercase coral category label above a title (e.g. "WHY YOU'RE HERE").

### `Title` / `Sub`
Screen title (display font, 30px) and subtitle (`--text-2`, max 34ch).

### `SectionLabel`
Bold inline label + optional muted right-aligned hint (e.g. "🔒 Only you see this").

### `Chip` — interest/selection tag · **frozen (states)**
Pill; props: `selected`, `onClick`, `emoji`, `tone` ('default' | 'sensitive' → teal), `small`.
Supports a `+N` count **badge** and a chevron child for expandable topics.

### `OptionCard` — choice card · **frozen (states)**
Row: emoji + (label + optional sub) + check/radio mark. Props: `selected`, `multi`
(square check vs round radio), `emoji`, `label`, `sub`, `accent`, `onClick`.
Single-select (depth, flirt, meeting) and gate cards (age, pledge) both use this.

### `Segmented`
Equal-width segmented control on a faint track. Used for language roles.

### `Primary` / `Ghost` — buttons
Primary = coral pill (full width, `disabled` supported). Ghost = text button (Skip).
(Secondary & SSO buttons are plain `.btn-secondary` / `.sso` in screen markup.)

### `Toggle`
46×28 switch row (label + sub + switch). Teal when on. (Available primitive for settings.)

### `Body` / `Footer` (screens-core.jsx)
Layout wrappers: scrollable body + fixed footer with the primary action.

---

## Interests engine (interests.jsx) · **frozen (pattern)**

### `InterestsInline` — default treatment
Topic chip grid; tapping a chip selects it and slides an **inline detail panel** open directly
below it (full-width). Chevron flips; `+N` badge shows sub-count. One panel open at a time.

### `InterestsSheet` — alternate treatment
Same grid; tapping opens a **bottom sheet** of sub-topics. Behind a prototype Tweak. Ship inline
unless told otherwise.

### `SubTopicCloud`
Sub-topic chip cloud + "Add your own" dashed input + optional **privacy/sensitive note**.
Honors `topic.privacyNote` (private topics) and the `sensitive` tone.

---

## Screen-level molecules

### Photo hero + sheet (Welcome)
Image area (≈47% height) with a dark sheet overlapping upward; grip, logo, title, outlined
"not a dating app" pill, primary + secondary buttons.

### SSO buttons + labeled fields (Sign in)
`Continue with Google` (4-color mark) / `Continue with Apple`, "or email" divider, labeled
email/password fields with Show/Hide, Forgot link, primary, "Join HOnly" footer link.

### Language row (`screens-extra.jsx`)
Removable row: language name + ✕ + 3-way role segmented control. "+ Add language" reveals a chip picker.

### Avatar grid (About)
6-col grid of emoji avatar tiles + an Upload tile. Selected = coral ring. Avatar is **equal** to a photo.

### Profile preview card (Done) — **profile card primitive**
Avatar tile + name (+ age) + **vibe badge** + completion %, then top-interest chips.
This is the seed of the planned **Profile card** (Screen 91) — reuse it.

### Match card + flirt indicator (Discover) · **frozen (mechanic)**
Person header (avatar + name + verified + status + match %), the **mutual flirt indicator**
(coral if both open/mutual, teal if platonic-protected), "why you match" chips, and a
"Start conversation" CTA (chat entry point).

### Safety / privacy notice — **frozen (presence)**
Recurring muted notes: off-limits "only you see this", location "off by default", the private
topic's "Private by default" line, and the flirt "mutual-only, reversible" copy. Build a small
reusable **SafetyNote / PrivacyNote** component for these; keep the copy verbatim.

---

## Requested components — current status

| Requested | Status | Where |
|-----------|--------|-------|
| Onboarding progress header | ✅ built | `NavBar` |
| Primary button | ✅ built | `Primary` / `.btn-primary` |
| Secondary button | ✅ built | `.btn-secondary`, `Ghost` |
| Choice card | ✅ built | `OptionCard` |
| Text input | ✅ built | `.text-input`, `.dark-field` |
| Profile card | ◑ partial | Done preview card + Discover match card → formalize for Screen 91 |
| Interest tag | ✅ built | `Chip` |
| Safety notice | ◑ inline copy | formalize as `SafetyNote` (see above) |
| Bottom navigation | ✗ not designed | needed for post-onboarding app (Screens 90/93/94) — route to design |
| Modal | ◑ partial | bottom **sheet** exists; a centered modal is not yet designed |
| Empty state | ✗ not designed | Screen 96 stub |

✅ build now · ◑ partially present, formalize · ✗ not yet designed (do not invent — see stubs)
