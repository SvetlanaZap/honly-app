# Screen 03 · Display name

![Display name](../exports/png/03-name.png)

| Field | Value |
|-------|-------|
| **Screen ID / key** | `name` |
| **Name** | Display name |
| **Step / eyebrow** | 2 / 10 · CREATE ACCOUNT |
| **Previous** | `age` |
| **Next** | `intent` |
| **Primary action** | "Continue" → intent (DISABLED until name non-empty) |
| **Secondary / back** | Back ← age |

## Purpose
Capture a public display name (need not be real).

## Layout
Eyebrow + title + sub + text input (trailing ✓ when valid) + fine hint.

## Components
NavBar, Title, Sub, .text-input, Primary.

## Copy (verbatim)
- Eyebrow: "Create account"
- Title: "What should people call you?"
- Sub: "Doesn't have to be your real name."
- Placeholder: "e.g. Alex" (max 24)
- Hint: "Public on your profile. Light impersonation & profanity filter only."
- Primary: "Continue"

## Conditional logic
Enter submits when valid. Apply real profanity/impersonation filter server-side.

---
*Reference: `src/index.html` → `window.__honlyShow('name')`. Tokens: `docs/design-system.md`. Freeze rules: `docs/developer-notes.md`.*
