# Screen 12 · Human pledge

![Human pledge](../exports/png/12-pledge.png)

| Field | Value |
|-------|-------|
| **Screen ID / key** | `pledge` |
| **Name** | Human pledge |
| **Step / eyebrow** | 10 / 10 · THE HONLY PART |
| **Previous** | `about` |
| **Next** | `done` |
| **Primary action** | "Enter HOnly" → done (DISABLED until checked) |
| **Secondary / back** | Back ← about |

## Purpose
Agree to be a real person acting in good faith.

## Layout
Eyebrow + title + sub + centered pledge card (🤝) with a single OptionCard.

## Components
NavBar, Title, Sub, OptionCard, Primary.

## Copy (verbatim)
- Eyebrow: "The HOnly part"
- Title: "One last thing."
- Sub: "Everyone here agrees to be a real human, here in good faith. That’s the whole deal."
- Card: "I'm a real person" / "…and I’ll treat others like real people."
- Primary: "Enter HOnly"

## Conditional logic
Required (st.pledge).

---
*Reference: `src/index.html` → `window.__honlyShow('pledge')`. Tokens: `docs/design-system.md`. Freeze rules: `docs/developer-notes.md`.*
