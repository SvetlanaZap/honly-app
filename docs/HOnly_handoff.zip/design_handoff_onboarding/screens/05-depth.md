# Screen 05 · Conversation depth

![Conversation depth](../exports/png/05-depth.png)

| Field | Value |
|-------|-------|
| **Screen ID / key** | `depth` |
| **Name** | Conversation depth |
| **Step / eyebrow** | 4 / 10 · YOUR VIBE |
| **Previous** | `intent` |
| **Next** | `interests` |
| **Primary action** | "Continue" → interests (DISABLED until one chosen) |
| **Secondary / back** | Back ← intent |

## Purpose
Single-select conversation tone.

## Layout
Eyebrow + title + sub + 3 stacked OptionCards.

## Components
NavBar, Title, Sub, OptionCard (single-select), Primary.

## Copy (verbatim)
- Eyebrow: "Your vibe"
- Title: "What conversations feel good right now?"
- Sub: "You can change this whenever your mood does."
- Cards: Light & fun 🎈 / "Banter, easy energy" · A bit of both 🌗 / "Read the room" · Deep & thoughtful 🕯️ / "Real talk, slow burn"

## Conditional logic
Single-select (st.depth).

---
*Reference: `src/index.html` → `window.__honlyShow('depth')`. Tokens: `docs/design-system.md`. Freeze rules: `docs/developer-notes.md`.*
