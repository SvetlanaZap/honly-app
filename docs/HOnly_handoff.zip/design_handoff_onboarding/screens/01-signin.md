# Screen 01 · Sign In (returning user)

![Sign In (returning user)](../exports/png/01-signin.png)

| Field | Value |
|-------|-------|
| **Screen ID / key** | `signin` |
| **Name** | Sign In (returning user) |
| **Step / eyebrow** | — (outside step counter) |
| **Previous** | `welcome` |
| **Next** | `discover` on success |
| **Primary action** | "Sign in" (email/password) → discover |
| **Secondary / back** | Google / Apple SSO → discover; "Forgot password?" (stub); "Join HOnly" → age |

## Purpose
Authenticate an existing user via SSO or email.

## Layout
Centered dark column: Logo, title, two SSO buttons, 'or email' divider, labeled email + password fields, Forgot link, Primary, footer link.

## Components
Logo, SSO buttons (.sso--google / .sso--apple), .dark-field (with Show/Hide), Primary.

## Copy (verbatim)
- Title: "Welcome back"
- Sub: "Real people are waiting for you."
- "Continue with Google" / "Continue with Apple"
- Divider: "or email"
- Fields: Email, Password (Show/Hide)
- "Forgot password?"
- Primary: "Sign in"
- Footer: "No account? Join HOnly"

## Conditional logic
Intentionally DARK. Back ← returns to welcome. SSO/auth are stubs — wire real providers.

---
*Reference: `src/index.html` → `window.__honlyShow('signin')`. Tokens: `docs/design-system.md`. Freeze rules: `docs/developer-notes.md`.*
