# Screen 92 · Chat screen  
> ⚠️ **PLANNED — NOT YET DESIGNED.** This is a spec stub, not a built screen. There is no
> approved visual for it yet. Build the layout in your stack respecting the **frozen anchors**
> below, and route final visual decisions back to the design owner. **Do not invent** final
> HOnly visuals and treat them as approved.

| Field | Value |
|-------|-------|
| **Screen ID / key** | `chat` |
| **Name** | Chat screen |
| **Status** | Planned (not in the built prototype) |

## Purpose
1:1 conversation between two matched humans.

## Entry point (frozen)
ONLY via 'Start conversation' on a match/profile card. No cold-DM/inbox-blast entry (frozen).

## Frozen anchors — must respect
- Conversation initiation stays gated behind a match view.
- Boundary context (platonic vs open-to-flirting) should remain legible & reversible in-chat.
- Report/Block reachable from the chat overflow menu (see 95).

## Yours to design/implement (route visuals to design owner)
- Message list, composer, presence/typing, attachments, system messages.
- Safety affordances (mute, leave), boundary-change entry, empty state (96).

---
*See `docs/developer-notes.md` for the full freeze contract and data model.*
