# Screen 10 · Languages (optional)

![Languages (optional)](../exports/png/10-languages.png)

| Field | Value |
|-------|-------|
| **Screen ID / key** | `langs` |
| **Name** | Languages (optional) |
| **Step / eyebrow** | 8 / 10 · LANGUAGES |
| **Previous** | `rhythm` |
| **Next** | `about` |
| **Primary action** | "Save & continue" → about |
| **Secondary / back** | "Skip" → about |

## Purpose
Optional: languages + a role per language.

## Layout
Eyebrow + title + sub; removable language rows each with a 3-way role segmented control; '+ Add language' reveals a chip picker.

## Components
NavBar, language row, Segmented (role), Chip (picker), footer-2.

## Copy (verbatim)
- Eyebrow: "Languages"
- Title: "Speak, practice, or just connect in."
- Roles: Fluent / native 💬 · Learning & want to practice 📈 · Love chatting with speakers 🌍
- Hint: about belonging, never nationality

## Conditional logic
Optional (Skip). 15 languages available; each added language carries a role.

---
*Reference: `src/index.html` → `window.__honlyShow('langs')`. Tokens: `docs/design-system.md`. Freeze rules: `docs/developer-notes.md`.*
