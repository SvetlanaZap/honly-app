# Screen 94 · Settings / safety  
> ⚠️ **PLANNED — NOT YET DESIGNED.** This is a spec stub, not a built screen. There is no
> approved visual for it yet. Build the layout in your stack respecting the **frozen anchors**
> below, and route final visual decisions back to the design owner. **Do not invent** final
> HOnly visuals and treat them as approved.

| Field | Value |
|-------|-------|
| **Screen ID / key** | `settings_safety` |
| **Name** | Settings / safety |
| **Status** | Planned (not in the built prototype) |

## Purpose
Account, privacy, and safety controls.

## Entry point (frozen)
Bottom nav / from My profile (93).

## Frozen anchors — must respect
- Surfaces the frozen privacy defaults: location OFF by default; flirt boundary mutual-only & reversible; off-limits private; private-topic visibility.
- Blocked-users management lives here; Report/Block flows link here.
- Support resources remain accessible (per Intent screen promise).

## Yours to design/implement (route visuals to design owner)
- Settings list structure, notification prefs, blocked list, data/account controls.

---
*See `docs/developer-notes.md` for the full freeze contract and data model.*
