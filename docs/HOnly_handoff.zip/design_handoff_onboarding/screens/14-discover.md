# Screen 14 · Discover — mutual flirt indicator (demo)

![Discover — mutual flirt indicator (demo)](../exports/png/14-discover-flirt-indicator.png)

| Field | Value |
|-------|-------|
| **Screen ID / key** | `discover (explore)` |
| **Name** | Discover — mutual flirt indicator (demo) |
| **Step / eyebrow** | — (outside step counter) |
| **Previous** | `done` (new) or `signin` (returning) |
| **Next** | chat (planned 92) |
| **Primary action** | "💬 Start conversation" (chat entry point — stub) |
| **Secondary / back** | "↺ Restart onboarding" → welcome (prototype only) |

## Purpose
Show what a first match feels like and demonstrate the mutual flirt indicator.

## Layout
Eyebrow + title + sub + match card (person header + flirt indicator + 'why you match' chips + CTA) + mechanics note.

## Components
match card, flirt indicator (coral/teal), Chip, Primary, mechanics list.

## Copy (verbatim)
- Eyebrow: "DISCOVER · A FIRST MATCH"
- Title: "Here's how a match feels."
- Sub: "No swiping — a curated person you choose to learn about."
- Indicator (both open/mutual): "You’re both open to a little flirting…"
- Indicator (platonic): "Kept platonic — your boundary travels with you…"

## Conditional logic
If st.flirt ∈ {open, mutual} → coral indicator; else teal platonic-protected indicator. Enabled only if BOTH opted in. This is the canonical mechanic example.

---
*Reference: `src/index.html` → `window.__honlyShow('discover')`. Tokens: `docs/design-system.md`. Freeze rules: `docs/developer-notes.md`.*
