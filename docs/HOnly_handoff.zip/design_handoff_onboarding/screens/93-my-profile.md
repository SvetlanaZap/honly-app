# Screen 93 · My profile  
> ⚠️ **PLANNED — NOT YET DESIGNED.** This is a spec stub, not a built screen. There is no
> approved visual for it yet. Build the layout in your stack respecting the **frozen anchors**
> below, and route final visual decisions back to the design owner. **Do not invent** final
> HOnly visuals and treat them as approved.

| Field | Value |
|-------|-------|
| **Screen ID / key** | `my_profile` |
| **Name** | My profile |
| **Status** | Planned (not in the built prototype) |

## Purpose
The user's own profile + the editable version of everything captured in onboarding.

## Entry point (frozen)
Bottom nav 'Profile' tab.

## Frozen anchors — must respect
- Every onboarding field is editable here and keeps its visibility control.
- Completion % nudge is friendly, never a wall.
- Private topics ('Something I’m carrying', off-limits) stay private by default; making any public is an explicit opt-in here.
- Avatar equal to photo.

## Yours to design/implement (route visuals to design owner)
- Edit layouts, visibility toggles UI, account section.
- Link to Settings/safety (94).

---
*See `docs/developer-notes.md` for the full freeze contract and data model.*
