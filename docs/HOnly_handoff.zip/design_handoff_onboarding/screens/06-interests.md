# Screen 06 · Interests — branching engine ★

![Interests — branching engine ★](../exports/png/06-interests.png)

| Field | Value |
|-------|-------|
| **Screen ID / key** | `interests` |
| **Name** | Interests — branching engine ★ |
| **Step / eyebrow** | 5 / 10 · WHAT YOU LOVE |
| **Previous** | `depth` |
| **Next** | `flirt` |
| **Primary action** | "Continue" → flirt (DISABLED until ≥3 topics) |
| **Secondary / back** | Back ← depth |

## Purpose
Pick ≥3 topics; optionally open a topic to add sub-topics via inline expansion.

## Layout
Eyebrow + title + sub + topic chip grid; selecting a chip slides an inline detail panel open directly below it. Footer shows a live counter.

## Components
NavBar, Title, Sub, Chip (with +N badge + chevron), InlinePanel + SubTopicCloud, counter, Primary.

## Copy (verbatim)
- Eyebrow: "What you love"
- Title: "What do you love talking about?"
- Sub: "Pick a few. Tap one to add detail — you can keep anything private."
- Counter: "Choose at least 3 · n/3" → "✨ n topics — nice mix"

## Conditional logic
See 06-interests.md addendum below. Sensitive topics teal. private_carrying has custom panel copy + privacy note + private_matching_only visibility. Inline treatment ships; bottom-sheet is an alternate. One panel open at a time. Parent counts alone; sub-topics optional+multi.

---
*Reference: `src/index.html` → `window.__honlyShow('interests')`. Tokens: `docs/design-system.md`. Freeze rules: `docs/developer-notes.md`.*
