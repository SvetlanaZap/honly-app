# Screen 09 · Rhythm + off-limits (optional)

![Rhythm + off-limits (optional)](../exports/png/09-rhythm.png)

| Field | Value |
|-------|-------|
| **Screen ID / key** | `rhythm` |
| **Name** | Rhythm + off-limits (optional) |
| **Step / eyebrow** | 7 / 10 · HOW YOU CHAT |
| **Previous** | `flirt` |
| **Next** | `langs` |
| **Primary action** | "Save & continue" → langs |
| **Secondary / back** | "Skip" → langs |

## Purpose
Optional: chat cadence + private off-limits topics.

## Layout
Eyebrow + title + sub; section 'How do you like to chat?' (3 OptionCards); section 'Anything you’d rather not talk about?' (private chip cloud) + hint.

## Components
NavBar, SectionLabel (with 🔒 hint), OptionCard, Chip (multi), footer-2 (Ghost+Primary).

## Copy (verbatim)
- Eyebrow: "How you chat"
- Rhythm: Quick back-and-forth ⚡ · A few messages a day 🌤️ · Slow & thoughtful 🌊
- Off-limits chips: Politics · Religion · Exes · Work · Health · Money · Family drama
- Hint: "We quietly steer matches away — your off-limits list is private."

## Conditional logic
Optional (Skip). Off-limits list is PRIVATE (only the user sees it).

---
*Reference: `src/index.html` → `window.__honlyShow('rhythm')`. Tokens: `docs/design-system.md`. Freeze rules: `docs/developer-notes.md`.*
