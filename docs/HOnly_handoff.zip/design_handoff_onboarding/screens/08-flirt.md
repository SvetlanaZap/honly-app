# Screen 08 · Flirt boundary

![Flirt boundary](../exports/png/08-flirt.png)

| Field | Value |
|-------|-------|
| **Screen ID / key** | `flirt` |
| **Name** | Flirt boundary |
| **Step / eyebrow** | 6 / 10 · BOUNDARIES |
| **Previous** | `interests` |
| **Next** | `rhythm` |
| **Primary action** | "Continue" → rhythm (DISABLED until one chosen) |
| **Secondary / back** | Back ← interests |

## Purpose
Set the flirting boundary — a core safety primitive.

## Layout
Eyebrow + title + sub + 4 stacked OptionCards + fine hint.

## Components
NavBar, Title, Sub, OptionCard (single-select; platonic teal accent), Primary.

## Copy (verbatim)
- Eyebrow: "Boundaries"
- Title: "How do you feel about light flirting?"
- Sub: "HOnly is about real conversation — flirting is optional and only ever mutual."
- Cards: Open to light flirting ✨ · Only if it's mutual 🤝 · Depends on the person 🤔 · Keep it platonic 🛡️ (protected)
- Hint: "Mutual-only, always reversible, never sexualised. “Keep it platonic” is a protected, hard signal."

## Conditional logic
Single-select (st.flirt). Drives the Discover flirt indicator. Platonic is a protected hard signal.

---
*Reference: `src/index.html` → `window.__honlyShow('flirt')`. Tokens: `docs/design-system.md`. Freeze rules: `docs/developer-notes.md`.*
