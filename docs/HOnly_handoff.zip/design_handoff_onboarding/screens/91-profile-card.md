# Screen 91 · Profile card / profile preview  
> ⚠️ **PLANNED — NOT YET DESIGNED.** This is a spec stub, not a built screen. There is no
> approved visual for it yet. Build the layout in your stack respecting the **frozen anchors**
> below, and route final visual decisions back to the design owner. **Do not invent** final
> HOnly visuals and treat them as approved.

| Field | Value |
|-------|-------|
| **Screen ID / key** | `profile_card` |
| **Name** | Profile card / profile preview |
| **Status** | Planned (not in the built prototype) |

## Purpose
A person's profile as seen by others: avatar/photo, name, age, vibe badge, shared interests, match %, boundary indicators.

## Entry point (frozen)
Tapping a person in discovery (90) or a match (14).

## Frozen anchors — must respect
- Formalize from the Done preview card (13) + Discover match card (14).
- Avatar is EQUAL to a photo — never face-forward nudging.
- Sensitive/private topics are NEVER shown unless the user explicitly opted that parent label public.
- Flirt boundary indicator (coral/teal) shown; platonic is a protected hard signal.
- Primary CTA is 'Start conversation' (the only chat entry).

## Yours to design/implement (route visuals to design owner)
- Full profile layout (photo treatment, sections, overflow menu).
- Report/Block must be reachable from the overflow menu (see 95).
- What's public vs private per field (respect onboarding visibility settings).

---
*See `docs/developer-notes.md` for the full freeze contract and data model.*
