# Screen 04 · Intent — why you're here

![Intent — why you're here](../exports/png/04-intent.png)

| Field | Value |
|-------|-------|
| **Screen ID / key** | `intent` |
| **Name** | Intent — why you're here |
| **Step / eyebrow** | 3 / 10 · WHY YOU'RE HERE |
| **Previous** | `depth`←/`name` |
| **Next** | `depth` |
| **Primary action** | "Continue" → depth (DISABLED until ≥1 selected) |
| **Secondary / back** | Back ← name |

## Purpose
Multi-select reasons for joining; drives matching.

## Layout
Eyebrow + title + sub + chip cloud (8 chips) + fine hint.

## Components
NavBar, Title, Sub, Chip (multi-select), Primary.

## Copy (verbatim)
- Eyebrow: "Why you're here"
- Title: "What brings you to HOnly?"
- Sub: "Pick anything that fits — you can change it anytime."
- Chips: Casual easy chats ☕ · Deeper conversations 🌙 · Someone to talk to 🫶 · Practicing a language 🗣️ · Talking in my own language 🌍 · Making real friends 🤝 · Open to light flirting ✨ · Just exploring 🧭
- Hint (KEEP): support-resources line for "a kind ear"

## Conditional logic
Multi-select. The support-resources reassurance line is a frozen trust primitive.

---
*Reference: `src/index.html` → `window.__honlyShow('intent')`. Tokens: `docs/design-system.md`. Freeze rules: `docs/developer-notes.md`.*
