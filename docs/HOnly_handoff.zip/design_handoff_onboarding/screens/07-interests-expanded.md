# Screen 07 · Interests — “Something I’m carrying” expanded

![Interests — “Something I’m carrying” expanded](../exports/png/07-interests-expanded.png)

| Field | Value |
|-------|-------|
| **Screen ID / key** | `interests` |
| **Name** | Interests — “Something I’m carrying” expanded |
| **Step / eyebrow** | 5 / 10 (detail) |
| **Previous** | (same screen as 06) |
| **Next** | (same screen as 06) |
| **Primary action** | — (part of Interests) |
| **Secondary / back** | “Remove” collapses + deselects the topic |

## Purpose
Reference state: the private sensitive topic selected with its inline panel open.

## Layout
Selected teal chip 🤲 'Something I’m carrying' (chevron up) with an inline panel below: title, muted helper, Remove pill, 8 sub-topic chips, privacy note.

## Components
Chip (sensitive/teal), InlinePanel, SubTopicCloud, privacy note.

## Copy (verbatim)
- Panel title: "What kind of thing would you like to talk about?"
- Helper (muted): "Some things are easier to talk about with someone outside your everyday circle — especially someone who understands. You can keep this private and use it only to help HOnly suggest better conversations."
- Sub-topics: Illness, recovery, and life changes · Trying to stop or change something · Past experiences I’m still processing · Feeling ashamed or alone with it · Relationship doubts or complicated feelings · Family or cultural pressure · Work pressure and career fears · Unusual interests I don’t usually share
- Privacy note: "🔒 Private by default. You choose what, if anything, appears on your profile."

## Conditional logic
private_matching_only. Sub-topics NEVER public. Warm, non-clinical — no crisis UI. 🤲 icon, teal styling, privacy note all frozen.

---
*Reference: `src/index.html` → `window.__honlyShow('interests')`. Tokens: `docs/design-system.md`. Freeze rules: `docs/developer-notes.md`.*
