# Screen 90 · Main grid / discovery  
> ⚠️ **PLANNED — NOT YET DESIGNED.** This is a spec stub, not a built screen. There is no
> approved visual for it yet. Build the layout in your stack respecting the **frozen anchors**
> below, and route final visual decisions back to the design owner. **Do not invent** final
> HOnly visuals and treat them as approved.

| Field | Value |
|-------|-------|
| **Screen ID / key** | `discovery` |
| **Name** | Main grid / discovery |
| **Status** | Planned (not in the built prototype) |

## Purpose
The post-onboarding home: a curated set of people/conversations to explore. Replaces the single-card Discover demo (Screen 14) with a browsable surface.

## Entry point (frozen)
From `done` (new user) and `signin` (returning user). Reachable via bottom nav 'Discover' tab.

## Frozen anchors — must respect
- No swiping — curated, choose-to-learn model (per Screen 14 copy).
- Each person surfaces as a profile/match card (reuse the Screen 91 card).
- Mutual flirt indicator + 'why you match' chips travel onto each card.
- Conversation only starts via a card's 'Start conversation' CTA (frozen chat entry point).

## Yours to design/implement (route visuals to design owner)
- Card grid/list layout, density, filters/sorting.
- Loading & empty states (see 96).
- Bottom navigation (see Components — not yet designed).

---
*See `docs/developer-notes.md` for the full freeze contract and data model.*
