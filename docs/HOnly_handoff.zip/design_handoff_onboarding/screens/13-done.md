# Screen 13 · Completion / profile preview

![Completion / profile preview](../exports/png/13-done.png)

| Field | Value |
|-------|-------|
| **Screen ID / key** | `done` |
| **Name** | Completion / profile preview |
| **Step / eyebrow** | — (outside step counter) |
| **Previous** | `pledge` |
| **Next** | `discover` |
| **Primary action** | "Start exploring →" → discover |
| **Secondary / back** | — |

## Purpose
Celebrate and show a profile-preview card.

## Layout
Burst 🎉 + eyebrow + title + sub + profile-preview card (avatar, name+age, vibe badge, completion %, top-interest chips) + footer.

## Components
Title, Sub, profile preview card, Primary.

## Copy (verbatim)
- Eyebrow: "You're in"
- Title: "Welcome to HOnly, {name}!"
- Sub: "You're part of a community of real humans having real conversations."
- Footer hint: "Add more anytime for better matches — never a wall."

## Conditional logic
completion(st) → %. This card is the seed of the planned Profile card (91).

---
*Reference: `src/index.html` → `window.__honlyShow('done')`. Tokens: `docs/design-system.md`. Freeze rules: `docs/developer-notes.md`.*
