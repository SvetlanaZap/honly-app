# Screen 95 · Report / block  
> ⚠️ **PLANNED — NOT YET DESIGNED.** This is a spec stub, not a built screen. There is no
> approved visual for it yet. Build the layout in your stack respecting the **frozen anchors**
> below, and route final visual decisions back to the design owner. **Do not invent** final
> HOnly visuals and treat them as approved.

| Field | Value |
|-------|-------|
| **Screen ID / key** | `report_block` |
| **Name** | Report / block |
| **Status** | Planned (not in the built prototype) |

## Purpose
Let a user report and/or block another user safely.

## Entry point (frozen)
From BOTH the chat overflow menu (92) and the profile overflow menu (91) — frozen.

## Frozen anchors — must respect
- Reachable from both chat and profile (do not bury).
- Blocking is immediate and respected everywhere; boundary signals are protected.
- Outcome is clear and reassuring, not punitive-feeling for the reporter.

## Yours to design/implement (route visuals to design owner)
- Reason taxonomy, confirmation, post-action state, link to blocked list (94).

---
*See `docs/developer-notes.md` for the full freeze contract and data model.*
