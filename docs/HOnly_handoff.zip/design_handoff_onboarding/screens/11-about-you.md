# Screen 11 · About you (optional)

![About you (optional)](../exports/png/11-about-you.png)

| Field | Value |
|-------|-------|
| **Screen ID / key** | `about` |
| **Name** | About you (optional) |
| **Step / eyebrow** | 9 / 10 · ABOUT YOU |
| **Previous** | `langs` |
| **Next** | `pledge` |
| **Primary action** | "Finish" → pledge |
| **Secondary / back** | "Skip for now" → pledge |

## Purpose
Optional profile details — every field optional with its own visibility.

## Layout
Sectioned: Today’s vibe (chips) · Avatar/photo (6-col grid + Upload) · Age · Gender · Location (off by default) · Meeting openness · Cultures.

## Components
NavBar, SectionLabel (+ visibility hints), Chip, avatar grid, OptionCard, footer-2.

## Copy (verbatim)
- Eyebrow: "About you"
- Title: "A little about you."
- Vibes: Chatty 🙂 · Mellow 😌 · Reflective 🤔 · Need a distraction 😅 · Motivated 💪 · Quiet today 😶
- Note: "An avatar is fully equal to a photo. We never nudge you toward a face."
- Location note: "off by default"
- Meeting note: "HOnly never pressures anyone to meet…"

## Conditional logic
All optional. Today’s vibe drives the Done badge. Location default 'none' (OFF). Avatar equal to photo.

---
*Reference: `src/index.html` → `window.__honlyShow('about')`. Tokens: `docs/design-system.md`. Freeze rules: `docs/developer-notes.md`.*
