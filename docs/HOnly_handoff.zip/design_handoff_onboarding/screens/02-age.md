# Screen 02 · Age gate

![Age gate](../exports/png/02-age.png)

| Field | Value |
|-------|-------|
| **Screen ID / key** | `age` |
| **Name** | Age gate |
| **Step / eyebrow** | 1 / 10 · QUICK CHECK |
| **Previous** | `welcome` (or `signin` via Join) |
| **Next** | `name` |
| **Primary action** | "Continue" → name (DISABLED until the card is selected) |
| **Secondary / back** | Back ← welcome |

## Purpose
Confirm the user is 18 or older.

## Layout
Eyebrow + title + sub + a single OptionCard.

## Components
NavBar, Eyebrow, Title, Sub, OptionCard, Primary.

## Copy (verbatim)
- Eyebrow: "Quick check"
- Title: "First, a quick check."
- Sub: "HOnly is for adults. Your exact age stays optional — you can add a range later."
- Card: "I'm 18 or older" / "Required to continue" (🔞)
- Primary: "Continue"

## Conditional logic
Hard gate: st.age18 must be true. Enforce server-side too.

---
*Reference: `src/index.html` → `window.__honlyShow('age')`. Tokens: `docs/design-system.md`. Freeze rules: `docs/developer-notes.md`.*
