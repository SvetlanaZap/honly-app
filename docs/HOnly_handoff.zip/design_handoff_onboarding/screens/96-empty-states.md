# Screen 96 · Empty states  
> ⚠️ **PLANNED — NOT YET DESIGNED.** This is a spec stub, not a built screen. There is no
> approved visual for it yet. Build the layout in your stack respecting the **frozen anchors**
> below, and route final visual decisions back to the design owner. **Do not invent** final
> HOnly visuals and treat them as approved.

| Field | Value |
|-------|-------|
| **Screen ID / key** | `empty_states` |
| **Name** | Empty states |
| **Status** | Planned (not in the built prototype) |

## Purpose
Reassuring, on-brand empty/zero-data and error states across the app.

## Entry point (frozen)
No matches yet (discovery 90), no messages yet (chat 92), no results after filtering, offline/error.

## Frozen anchors — must respect
- Warm, human, never blaming tone (matches onboarding voice).
- Never pressure (no 'invite everyone' dark patterns).
- Use the brand's emoji-forward, gentle visual language; coral/teal accents.

## Yours to design/implement (route visuals to design owner)
- Per-context illustration/emoji, copy, and primary action for each empty/error case.

---
*See `docs/developer-notes.md` for the full freeze contract and data model.*
