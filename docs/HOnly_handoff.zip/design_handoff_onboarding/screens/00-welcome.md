# Screen 00 · Welcome / Landing

![Welcome / Landing](../exports/png/00-welcome.png)

| Field | Value |
|-------|-------|
| **Screen ID / key** | `welcome` |
| **Name** | Welcome / Landing |
| **Step / eyebrow** | — (outside step counter) |
| **Previous** | — (entry point) |
| **Next** | `age` (Join) or `signin` (Sign in) |
| **Primary action** | "Join HOnly — it's free" → age |
| **Secondary / back** | "Sign in" → signin |

## Purpose
First impression and brand promise; split into Join (new) and Sign in (returning) paths.

## Layout
Photo hero (~47% height) with a dark navy sheet overlapping upward (−34px, 32px top radius, grip handle). No nav bar / progress.

## Components
Photo hero (image-slot), Logo, hero title, outlined pill, Primary, Secondary (.btn-secondary).

## Copy (verbatim)
- Logo: H●nly
- Title: "Meet someone **real**"
- Sub: "Casual chats, deep conversations, real human connection."
- Pill: "THIS IS NOT A DATING APP · NO PRESSURE"
- Primary: "Join HOnly — it's free"
- Secondary: "Sign in"

## Conditional logic
Intentionally DARK in both themes. Photo is a user/brand image (placeholder in prototype).

---
*Reference: `src/index.html` → `window.__honlyShow('welcome')`. Tokens: `docs/design-system.md`. Freeze rules: `docs/developer-notes.md`.*
