// HOnly onboarding — interests engine (Screen 5), both treatments
const { useState: useStateI } = React;

// Sub-topic chip cloud shared by both treatments
function SubTopicCloud({ topic, picked, onToggle, onAdd }) {
  const [draft, setDraft] = useStateI("");
  return (
    <div className="subcloud">
      <div className="chips">
        {topic.subs.map((s) => (
          <Chip key={s} small selected={picked.includes(s)}
            tone={topic.sensitive ? "sensitive" : "default"}
            onClick={() => onToggle(s)}>{s}</Chip>
        ))}
      </div>
      <div className="addown">
        <input className="addown-input" placeholder="+ Add your own" value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && draft.trim()) { onAdd(draft.trim()); setDraft(""); } }} />
        {draft.trim() ? <button className="addown-go" onClick={() => { onAdd(draft.trim()); setDraft(""); }}>Add</button> : null}
      </div>
      {topic.privacyNote
        ? <p className="privacynote"><span className="privacynote-ico">🔒</span>{topic.privacyNote}</p>
        : topic.sensitive ? <p className="sensnote">Shown only as “happy to talk about”, never as a label about you. Visible only to your matches.</p> : null}
    </div>
  );
}

// INLINE treatment: tap a chip → its sub-topic chips slide open inline, right below it
function InterestsInline({ topics, toggleTopic, toggleSub, addSub }) {
  const [open, setOpen] = useStateI(null);
  const handle = (t) => {
    const sel = !!topics[t.id];
    if (!sel) { toggleTopic(t.id); setOpen(t.id); }     // select + open
    else if (open === t.id) { setOpen(null); }          // collapse, stay selected
    else { setOpen(t.id); }                             // switch open topic
  };
  return (
    <div className="chipflow">
      {TAXONOMY.map((t) => {
        const sel = !!topics[t.id];
        const n = sel ? topics[t.id].length : 0;
        const isOpen = open === t.id;
        return (
          <React.Fragment key={t.id}>
            <Chip emoji={t.emoji} selected={sel} tone={t.sensitive ? "sensitive" : "default"}
              onClick={() => handle(t)}>
              {t.label}
              {n > 0 ? <span className="chip-badge">+{n}</span> : null}
              {sel ? (
                <svg className="chip-chev" style={{ transform: isOpen ? "rotate(180deg)" : "none" }}
                  width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
              ) : null}
            </Chip>
            {isOpen ? (
              <div className="inline-subs">
                <div className="inline-panel">
                  <div className="inline-panel-head">
                    <div className="inline-panel-titles">
                      <span className="inline-panel-title">
                        {t.panelTitle || <>What about {t.label.toLowerCase()} do you enjoy? <span className="opt-faint">optional</span></>}
                      </span>
                      {t.panelHelper ? <p className="inline-panel-helper">{t.panelHelper}</p> : null}
                    </div>
                    <button className="inline-remove" onClick={() => { toggleTopic(t.id); setOpen(null); }}>Remove</button>
                  </div>
                  <SubTopicCloud topic={t} picked={topics[t.id] || []}
                    onToggle={(s) => toggleSub(t.id, s)} onAdd={(s) => addSub(t.id, s)} />
                </div>
              </div>
            ) : null}
          </React.Fragment>
        );
      })}
    </div>
  );
}

// SHEET treatment: topic grid; tapping opens a bottom sheet of sub-topics
function InterestsSheet({ topics, toggleTopic, toggleSub, addSub }) {
  const [sheet, setSheet] = useStateI(null);
  const t = sheet ? TAXONOMY.find((x) => x.id === sheet) : null;
  return (
    <div>
      <div className="chips">
        {TAXONOMY.map((tx) => {
          const sel = !!topics[tx.id];
          const n = sel ? topics[tx.id].length : 0;
          return (
            <Chip key={tx.id} emoji={tx.emoji} selected={sel}
              tone={tx.sensitive ? "sensitive" : "default"}
              onClick={() => { if (!sel) toggleTopic(tx.id); setSheet(tx.id); }}>
              {tx.label}{n > 0 ? <span className="chip-badge">+{n}</span> : null}
            </Chip>
          );
        })}
      </div>
      {t ? (
        <div className="sheet-scrim" onClick={() => setSheet(null)}>
          <div className="sheet" onClick={(e) => e.stopPropagation()}>
            <div className="sheet-grip" />
            <div className="sheet-head">
              <span className="sheet-emoji">{t.emoji}</span>
              <div>
                <div className="sheet-title">{t.panelTitle || t.label}</div>
                <div className="sheet-sub">{t.panelHelper || "What about it do you enjoy? Optional."}</div>
              </div>
              {topics[t.id] ? (
                <button className="sheet-remove" onClick={() => { toggleTopic(t.id); setSheet(null); }}>Remove</button>
              ) : null}
            </div>
            <SubTopicCloud topic={t} picked={topics[t.id] || []}
              onToggle={(s) => toggleSub(t.id, s)} onAdd={(s) => addSub(t.id, s)} />
            <button className="btn-primary sheet-done" onClick={() => setSheet(null)}>Done</button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

Object.assign(window, { InterestsInline, InterestsSheet });
