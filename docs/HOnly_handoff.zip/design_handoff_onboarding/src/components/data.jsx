// HOnly onboarding — data layer (taxonomy, option sets, config)
// Exposed on window for the other Babel scripts.

// ── Screen 3: Intent ──────────────────────────────────────────────
const INTENTS = [
  { id: "casual",   label: "Casual, easy chats",        emoji: "☕" },
  { id: "deep",     label: "Deeper conversations",      emoji: "🌙" },
  { id: "kindear",  label: "Someone to talk to",        emoji: "🫶" },
  { id: "practice", label: "Practicing a language",     emoji: "🗣️" },
  { id: "ownlang",  label: "Talking in my own language",emoji: "🌍" },
  { id: "friends",  label: "Making real friends",       emoji: "🤝" },
  { id: "flirt",    label: "Open to light flirting",    emoji: "✨" },
  { id: "explore",  label: "Just exploring",            emoji: "🧭" },
];

// ── Screen 4: Depth ───────────────────────────────────────────────
const DEPTHS = [
  { id: "light", label: "Light & fun",     sub: "Banter, easy energy",      emoji: "🎈" },
  { id: "both",  label: "A bit of both",   sub: "Read the room",            emoji: "🌗" },
  { id: "deep",  label: "Deep & thoughtful", sub: "Real talk, slow burn",   emoji: "🕯️" },
];

// ── Screen 5: Interest taxonomy (branching) ───────────────────────
const TAXONOMY = [
  { id: "watch",   emoji: "🎧", label: "Listening & watching",
    subs: ["Podcasts","True crime","Audiobooks","Film","TV & streaming","YouTube","Documentaries","Anime"] },
  { id: "music",   emoji: "🎵", label: "Music",
    subs: ["Pop","Rock","Hip-hop","Electronic","Classical","Jazz","K-pop","Indie","Making music","Concerts & live"] },
  { id: "books",   emoji: "📚", label: "Books & writing",
    subs: ["Fiction","Non-fiction","Poetry","Fantasy & sci-fi","Writing my own","Recommendations"] },
  { id: "gaming",  emoji: "🎮", label: "Gaming",
    subs: ["PC","Console","Mobile","Cozy games","Competitive","Tabletop & D&D","Retro"] },
  { id: "science", emoji: "🔬", label: "Science & tech",
    subs: ["Space","AI","Gadgets","Coding","Psychology","Nature & biology","Future & ideas"] },
  { id: "philo",   emoji: "💭", label: "Philosophy & big questions",
    subs: ["Meaning of life","Ethics","Consciousness","Stoicism","Friendly debates"] },
  // ── Sensitive/private topic ───────────────────────────────────────
  // DEV NOTE — data model for the private "carrying" topic:
  //   Parent topic key:   private_carrying
  //   Parent label:       Something I'm carrying
  //   Subtopics:          optional + multi-select. The parent chip ALONE counts as a
  //                       selected topic — never force a subtopic after tapping it.
  //   Default visibility: private_matching_only — selected subtopics personalise matches
  //                       but are NEVER shown publicly on the profile.
  //   Public exposure:    the parent MAY appear as a broad public label ONLY if the user
  //                       later explicitly opts in (visibility lives in profile settings,
  //                       not here). This is a conversation preference, not a therapy intake.
  //   `panelTitle` / `panelHelper` / `privacyNote` override the generic expansion copy so
  //   the tone stays warm and in-control rather than clinical.
  { id: "private_carrying", emoji: "🤲", label: "Something I'm carrying", sensitive: true,
    panelTitle: "What kind of thing would you like to talk about?",
    panelHelper: "Some things are easier to talk about with someone outside your everyday circle — especially someone who understands. You can keep this private and use it only to help HOnly suggest better conversations.",
    privacyNote: "Private by default. You choose what, if anything, appears on your profile.",
    subs: ["Illness, recovery, and life changes","Trying to stop or change something","Past experiences I'm still processing","Feeling ashamed or alone with it","Relationship doubts or complicated feelings","Family or cultural pressure","Work pressure and career fears","Unusual interests I don't usually share"] },
  { id: "travel",  emoji: "✈️", label: "Travel & cultures",
    subs: ["Backpacking","Living abroad","Food travel","A culture I'm from","A culture I'm curious about","Hidden gems"] },
  { id: "food",    emoji: "🍜", label: "Food & cooking",
    subs: ["Home cooking","Baking","Coffee","Tea","Restaurants","Specific cuisines","Veggie / vegan"] },
  { id: "art",     emoji: "🎨", label: "Art & creativity",
    subs: ["Drawing","Photography","Design","Crafts","Fashion","Film-making"] },
  { id: "sport",   emoji: "🏃", label: "Sport & movement",
    subs: ["Running","Gym & lifting","Yoga","Football","Climbing","Cycling","Martial arts","Dance"] },
  { id: "nature",  emoji: "🏔️", label: "Nature & outdoors",
    subs: ["Hiking","Camping","Gardening","Birdwatching","Beaches","Mountains"] },
  { id: "spirit",  emoji: "🔮", label: "Spirituality",
    subs: ["Meditation","Buddhism","Astrology","Tarot","Manifestation","Psychedelics & consciousness","Religion & faith","Agnostic / secular","Energy & healing"], sensitive: true },
  { id: "pets",    emoji: "🐾", label: "Pets & animals",
    subs: ["Dogs","Cats","Birds","Reptiles","Horses","Wildlife","Rescue & fostering"] },
  { id: "family",  emoji: "👪", label: "Family & relationships",
    subs: ["Friendship","Dating life","Single life","Married life","Divorce & starting over","Co-parenting","Raising teenagers","Long-distance","In-laws & family drama","Complicated relationships","Caring for aging parents"], sensitive: true },
  { id: "mind",    emoji: "🌱", label: "Mental wellbeing",
    subs: ["Mindfulness","Therapy & growth","Burnout","Anxiety","Grief","Just venting sometimes"], sensitive: true },
  { id: "work",    emoji: "💼", label: "Work & ambition",
    subs: ["Career changes","Side projects","Entrepreneurship","Studying","Burnout at work","Money & saving"] },
  { id: "humour",  emoji: "😂", label: "Humour & internet",
    subs: ["Memes","Banter","Internet culture","Niche humour"] },
  { id: "news",    emoji: "📰", label: "Current events",
    subs: ["World news","Local news","Tech news","Social issues"], optin: true },
];

// ── Screen 6: Flirt ───────────────────────────────────────────────
const FLIRT = [
  { id: "open",     label: "Open to light flirting",  sub: "Playful is welcome",       emoji: "✨" },
  { id: "mutual",   label: "Only if it's mutual",     sub: "Match my energy",          emoji: "🤝" },
  { id: "depends",  label: "Depends on the person",   sub: "Platonic until I signal",  emoji: "🤔" },
  { id: "platonic", label: "Keep it platonic",        sub: "A protected, hard signal", emoji: "🛡️" },
];

// ── Screen 7: Rhythm + off-limits ─────────────────────────────────
const RHYTHM = [
  { id: "quick", label: "Quick back-and-forth", emoji: "⚡" },
  { id: "daily", label: "A few messages a day",  emoji: "🌤️" },
  { id: "slow",  label: "Slow & thoughtful",     emoji: "🌊" },
];
const OFFLIMITS = ["Politics","Religion","Exes","Work","Health","Money","Family drama"];

// ── Screen 8: Languages ───────────────────────────────────────────
const LANGUAGES = ["English","Spanish","German","French","Portuguese","Italian","Mandarin","Japanese","Korean","Arabic","Hindi","Russian","Turkish","Dutch","Polish"];
const LANG_ROLES = [
  { id: "native",   label: "Fluent / native",            emoji: "💬" },
  { id: "learning", label: "Learning & want to practice", emoji: "📈" },
  { id: "connect",  label: "Love chatting with speakers", emoji: "🌍" },
];

// ── Screen 9: About you ───────────────────────────────────────────
const VIBES = [
  { id: "chatty",  label: "Chatty",            emoji: "🙂" },
  { id: "mellow",  label: "Mellow",            emoji: "😌" },
  { id: "reflect", label: "Reflective",        emoji: "🤔" },
  { id: "distract",label: "Need a distraction",emoji: "😅" },
  { id: "motiv",   label: "Motivated",         emoji: "💪" },
  { id: "quiet",   label: "Quiet today",       emoji: "😶" },
];
const AVATARS = ["🦊","🐢","🦉","🐙","🦋","🌵","🍄","🐝","🦜","🌊","🪐","🎈"];
const AGES = ["18–24","25–34","35–49","50+","Prefer not to say"];
const GENDERS = ["Woman","Man","Non-binary","Self-describe","Prefer not to say"];
const LOCATION = [
  { id: "none",    label: "Don't share",            sub: "Default" },
  { id: "country", label: "Country only",           sub: "" },
  { id: "city",    label: "City / area",            sub: "Coarse, never exact" },
  { id: "tz",      label: "Region for timezone",    sub: "" },
];
const MEETING = [
  { id: "online",  label: "Online only for me",                emoji: "💻" },
  { id: "maybe",   label: "Maybe, if we click",                emoji: "🌱" },
  { id: "open",    label: "Open to meeting in public eventually", emoji: "🚶" },
];

// ── Flow definition ───────────────────────────────────────────────
// label = small caps category eyebrow shown in the header
const FLOW = [
  { key: "welcome",  cat: null,                  required: true,  inSpine: false },
  { key: "age",      cat: "QUICK CHECK",         required: true,  inSpine: true  },
  { key: "name",     cat: "CREATE ACCOUNT",      required: true,  inSpine: true  },
  { key: "intent",   cat: "WHY YOU'RE HERE",     required: true,  inSpine: true  },
  { key: "depth",    cat: "YOUR VIBE",           required: true,  inSpine: true  },
  { key: "interests",cat: "WHAT YOU LOVE",       required: true,  inSpine: true  },
  { key: "flirt",    cat: "BOUNDARIES",          required: true,  inSpine: true  },
  { key: "rhythm",   cat: "HOW YOU CHAT",        required: false, inSpine: false, optional: true },
  { key: "langs",    cat: "LANGUAGES",           required: false, inSpine: false, optional: true },
  { key: "about",    cat: "ABOUT YOU",           required: false, inSpine: false, optional: true },
  { key: "pledge",   cat: "THE HONLY PART",      required: true,  inSpine: false },
  { key: "done",     cat: null,                  required: false, inSpine: false },
];

Object.assign(window, {
  INTENTS, DEPTHS, TAXONOMY, FLIRT, RHYTHM, OFFLIMITS,
  LANGUAGES, LANG_ROLES, VIBES, AVATARS, AGES, GENDERS, LOCATION, MEETING, FLOW,
});
