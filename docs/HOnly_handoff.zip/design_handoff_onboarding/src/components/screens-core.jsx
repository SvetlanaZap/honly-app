// HOnly onboarding — screens 0–6 (welcome → flirt)
const { useState: useStateS } = React;

// Reusable scroll body + footer wrapper
function Body({ children }) { return <div className="screen-body">{children}</div>; }
function Footer({ children }) { return <div className="screen-footer">{children}</div>; }

// ── 0 Welcome (photo hero + dark sheet) ───────────────────────────
function WelcomeScreen({ next, go }) {
  return (
    <div className="screen screen--welcome">
      <div className="welcome-photo">
        <image-slot id="welcome-hero" fit="cover" placeholder="Drop a photo — two hands / human connection"></image-slot>
      </div>
      <div className="welcome-sheet">
        <div className="w-grip" />
        <Logo className="w-logo" />
        <h1 className="w-title">Meet someone <span className="accent">real</span></h1>
        <p className="w-sub">Casual chats, deep conversations, real human connection.</p>
        <div className="pill-outline">THIS IS NOT A DATING APP · NO PRESSURE</div>
        <div className="w-actions">
          <Primary onClick={next}>Join HOnly — it's free</Primary>
          <button className="btn-secondary" onClick={() => go("signin")}>Sign in</button>
        </div>
      </div>
    </div>
  );
}

// ── Sign In (dark auth · SSO + email) ─────────────────────────────
function GoogleIcon() {
  return (
    <svg className="sso-ico" viewBox="0 0 48 48" aria-hidden="true">
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3c-1.6 4.7-6.1 8-11.3 8a12 12 0 110-24c3.1 0 5.9 1.2 8 3.1l5.7-5.7A20 20 0 1024 44c11 0 20-9 20-20 0-1.3-.1-2.5-.4-3.5z"/>
      <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8A12 12 0 0124 12c3.1 0 5.9 1.2 8 3.1l5.7-5.7A20 20 0 006.3 14.7z"/>
      <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2A12 12 0 0124 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z"/>
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3a12 12 0 01-4.1 5.6l6.2 5.2C39.9 36.6 44 31 44 24c0-1.3-.1-2.5-.4-3.5z"/>
    </svg>
  );
}
function AppleIcon() {
  return (
    <svg className="sso-ico" viewBox="0 0 24 24" fill="#fff" aria-hidden="true">
      <path d="M16.4 12.7c0-2.2 1.8-3.3 1.9-3.4-1-1.5-2.6-1.7-3.2-1.7-1.4-.1-2.6.8-3.3.8-.7 0-1.7-.8-2.8-.8-1.5 0-2.8.8-3.6 2.2-1.5 2.6-.4 6.5 1.1 8.6.7 1 1.6 2.2 2.7 2.2 1.1 0 1.5-.7 2.8-.7s1.6.7 2.8.7 1.9-1 2.6-2c.8-1.2 1.2-2.3 1.2-2.4-.1 0-2.3-.9-2.3-3.5zM14.2 6.2c.6-.7 1-1.7.9-2.7-.9 0-1.9.6-2.5 1.3-.5.6-1 1.6-.9 2.6 1 .1 1.9-.5 2.5-1.2z"/>
    </svg>
  );
}
function SignInScreen({ go }) {
  const [show, setShow] = useStateS(false);
  const [focus, setFocus] = useStateS(null);
  return (
    <div className="screen screen--signin">
      <div className="screen-body signin-body">
        <Logo className="si-logo" />
        <h1 className="si-title">Welcome back</h1>
        <p className="si-sub">Real people are waiting for you.</p>

        <button className="sso sso--google" onClick={() => go("explore")}><GoogleIcon /> Continue with Google</button>
        <button className="sso sso--apple" onClick={() => go("explore")}><AppleIcon /> Continue with Apple</button>

        <div className="divider">or email</div>

        <div className={"dark-field" + (focus === "e" ? " is-active" : "")}>
          <div className="df-label">Email</div>
          <input className="df-input" type="email" placeholder="alex@example.com"
            onFocus={() => setFocus("e")} onBlur={() => setFocus(null)} />
        </div>
        <div className={"dark-field" + (focus === "p" ? " is-active" : "")}>
          <div className="df-label">Password</div>
          <input className="df-input" type={show ? "text" : "password"} placeholder="••••••••"
            onFocus={() => setFocus("p")} onBlur={() => setFocus(null)} />
          <button className="df-show" onClick={() => setShow((s) => !s)}>{show ? "Hide" : "Show"}</button>
        </div>
        <a className="forgot" href="#" onClick={(e) => e.preventDefault()}>Forgot password?</a>

        <Primary onClick={() => go("explore")}>Sign in</Primary>
        <p className="signin-foot">No account? <a href="#" onClick={(e) => { e.preventDefault(); go("age"); }}>Join HOnly</a></p>
      </div>
    </div>
  );
}

// ── 1 Age gate ────────────────────────────────────────────────────
function AgeScreen({ st, set, next }) {
  return (
    <>
      <Body>
        <Eyebrow>Quick check</Eyebrow>
        <Title>First, a quick check.</Title>
        <Sub>HOnly is for adults. Your exact age stays optional — you can add a range later.</Sub>
        <OptionCard selected={st.age18} emoji="🔞" label="I'm 18 or older"
          sub="Required to continue" onClick={() => set({ age18: !st.age18 })} />
      </Body>
      <Footer>
        <Primary onClick={next} disabled={!st.age18}>Continue</Primary>
      </Footer>
    </>
  );
}

// ── 2 Display name ────────────────────────────────────────────────
function NameScreen({ st, set, next }) {
  return (
    <>
      <Body>
        <Eyebrow>Create account</Eyebrow>
        <Title>What should people call you?</Title>
        <Sub>Doesn't have to be your real name.</Sub>
        <div className="field">
          <input className="text-input" autoFocus placeholder="e.g. Alex"
            value={st.name} maxLength={24}
            onChange={(e) => set({ name: e.target.value })}
            onKeyDown={(e) => { if (e.key === "Enter" && st.name.trim()) next(); }} />
          {st.name.trim() ? <span className="field-check">✓</span> : null}
        </div>
        <p className="finehint">Public on your profile. Light impersonation & profanity filter only.</p>
      </Body>
      <Footer>
        <Primary onClick={next} disabled={!st.name.trim()}>Continue</Primary>
      </Footer>
    </>
  );
}

// ── 3 Intent ──────────────────────────────────────────────────────
function IntentScreen({ st, set, next }) {
  const toggle = (id) => {
    const has = st.intent.includes(id);
    set({ intent: has ? st.intent.filter((x) => x !== id) : [...st.intent, id] });
  };
  return (
    <>
      <Body>
        <Eyebrow>Why you're here</Eyebrow>
        <Title>What brings you to HOnly?</Title>
        <Sub>Pick anything that fits — you can change it anytime.</Sub>
        <div className="chips chips--lg">
          {INTENTS.map((i) => (
            <Chip key={i.id} emoji={i.emoji} selected={st.intent.includes(i.id)}
              onClick={() => toggle(i.id)}>{i.label}</Chip>
          ))}
        </div>
        <p className="finehint">Looking for “a kind ear”? You'll always find real <a href="#" onClick={(e)=>e.preventDefault()}>support resources</a> too — HOnly doesn't replace professional help.</p>
      </Body>
      <Footer>
        <Primary onClick={next} disabled={st.intent.length === 0}>Continue</Primary>
      </Footer>
    </>
  );
}

// ── 4 Depth ───────────────────────────────────────────────────────
function DepthScreen({ st, set, next }) {
  return (
    <>
      <Body>
        <Eyebrow>Your vibe</Eyebrow>
        <Title>What conversations feel good right now?</Title>
        <Sub>You can change this whenever your mood does.</Sub>
        <div className="stack">
          {DEPTHS.map((d) => (
            <OptionCard key={d.id} emoji={d.emoji} label={d.label} sub={d.sub}
              selected={st.depth === d.id} onClick={() => set({ depth: d.id })} />
          ))}
        </div>
      </Body>
      <Footer>
        <Primary onClick={next} disabled={!st.depth}>Continue</Primary>
      </Footer>
    </>
  );
}

// ── 5 Interests (branching) ───────────────────────────────────────
function InterestsScreen({ st, set, next, tweaks }) {
  const topics = st.topics;
  const toggleTopic = (id) => {
    const t = { ...topics };
    if (t[id]) delete t[id]; else t[id] = [];
    set({ topics: t });
  };
  const toggleSub = (id, s) => {
    const cur = topics[id] || [];
    const t = { ...topics, [id]: cur.includes(s) ? cur.filter((x) => x !== s) : [...cur, s] };
    set({ topics: t });
  };
  const addSub = (id, s) => {
    const cur = topics[id] || [];
    if (cur.includes(s)) return;
    set({ topics: { ...topics, [id]: [...cur, s] } });
  };
  const count = Object.keys(topics).length;
  const Engine = tweaks.interestsStyle === "sheet" ? InterestsSheet : InterestsInline;
  return (
    <>
      <Body>
        <Eyebrow>What you love</Eyebrow>
        {/* Title kept as-is per spec. ALT (if "love" ever feels too light next to the
            private "Something I'm carrying" topic): "What would you like to talk about?" */}
        <Title>What do you love talking about?</Title>
        <Sub>Pick a few. Tap one to add detail — you can keep anything private.</Sub>
        <Engine topics={topics} toggleTopic={toggleTopic} toggleSub={toggleSub} addSub={addSub} />
      </Body>
      <Footer>
        <div className={"counter" + (count >= 3 ? " is-ok" : "")}>
          {count >= 3 ? <>✨ <b>{count} topics</b> — nice mix</> : <>Choose at least 3 · <b>{count}/3</b></>}
        </div>
        <Primary onClick={next} disabled={count < 3}>Continue</Primary>
      </Footer>
    </>
  );
}

// ── 6 Flirt ───────────────────────────────────────────────────────
function FlirtScreen({ st, set, next }) {
  return (
    <>
      <Body>
        <Eyebrow>Boundaries</Eyebrow>
        <Title>How do you feel about light flirting?</Title>
        <Sub>HOnly is about real conversation — flirting is optional and only ever mutual.</Sub>
        <div className="stack">
          {FLIRT.map((f) => (
            <OptionCard key={f.id} emoji={f.emoji} label={f.label} sub={f.sub}
              selected={st.flirt === f.id} onClick={() => set({ flirt: f.id })}
              accent={f.id === "platonic" ? "var(--teal)" : null} />
          ))}
        </div>
        <p className="finehint">Mutual-only, always reversible, never sexualised. “Keep it platonic” is a protected, hard signal.</p>
      </Body>
      <Footer>
        <Primary onClick={next} disabled={!st.flirt}>Continue</Primary>
      </Footer>
    </>
  );
}

Object.assign(window, {
  Body, Footer, WelcomeScreen, SignInScreen, AgeScreen, NameScreen, IntentScreen, DepthScreen, InterestsScreen, FlirtScreen,
});
