// HOnly onboarding — shared UI primitives
const { useState, useEffect, useRef } = React;

// Phone status bar
function StatusBar() {
  return (
    <div className="statusbar">
      <span className="sb-time">9:41</span>
      <span className="sb-icons">
        <svg width="18" height="11" viewBox="0 0 18 11" fill="currentColor"><rect x="0" y="7" width="3" height="4" rx="1"/><rect x="5" y="4.5" width="3" height="6.5" rx="1"/><rect x="10" y="2" width="3" height="9" rx="1"/><rect x="15" y="0" width="3" height="11" rx="1"/></svg>
        <svg width="16" height="12" viewBox="0 0 16 12" fill="currentColor"><path d="M8 11.2a1.4 1.4 0 100-2.8 1.4 1.4 0 000 2.8z"/><path d="M2.2 5.1a8.3 8.3 0 0111.6 0l-1.5 1.5a6.1 6.1 0 00-8.6 0L2.2 5.1z" opacity=".9"/><path d="M4.6 7.5a4.8 4.8 0 016.8 0L9.9 9a2.7 2.7 0 00-3.8 0L4.6 7.5z"/></svg>
        <span className="sb-batt"><span className="sb-batt-fill" /></span>
      </span>
    </div>
  );
}

// Top nav: back arrow + step counter + progress (bar by default, dots in light theme)
function NavBar({ onBack, step, total, canBack, dots }) {
  const pct = Math.round((step / total) * 100);
  return (
    <div className="navbar">
      <div className="navbar-row">
        <button className={"backbtn" + (canBack ? "" : " is-hidden")} onClick={onBack} aria-label="Back">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M15 18l-6-6 6-6" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </button>
        <div className="stepcount">{step}<span>/{total}</span></div>
      </div>
      {dots ? (
        <div className="progress-dots" role="progressbar" aria-valuenow={step} aria-valuemax={total}>
          {Array.from({ length: total }).map((_, i) => (
            <span key={i} className={"pdot" + (i < step ? " is-done" : "") + (i === step - 1 ? " is-cur" : "")} />
          ))}
        </div>
      ) : (
        <div className="progress"><div className="progress-fill" style={{ width: pct + "%" }} /></div>
      )}
    </div>
  );
}

function Eyebrow({ children }) {
  return <div className="eyebrow">{children}</div>;
}

// HOnly wordmark: coral H + teal speech-bubble o (with notification badge) + white nly
function Logo({ small, className }) {
  return (
    <span className={"logo" + (small ? " logo--sm" : "") + (className ? " " + className : "")} aria-label="HOnly">
      <span className="logo-h">H</span>
      <span className="logo-o">
        <span className="logo-dots">
          <span className="logo-dot c" /><span className="logo-dot" /><span className="logo-dot" />
        </span>
        <span className="logo-badge">1</span>
      </span>
      <span className="logo-nly">nly</span>
    </span>
  );
}

// Big two-line display title; pass an array of lines or a string
function Title({ children }) {
  return <h1 className="title">{children}</h1>;
}
function Sub({ children }) {
  return <p className="sub">{children}</p>;
}
function SectionLabel({ children, hint }) {
  return (
    <div className="seclabel">
      <span>{children}</span>
      {hint ? <span className="seclabel-hint">{hint}</span> : null}
    </div>
  );
}

// Selectable chip (pill). tone: 'default' | 'sensitive'
function Chip({ selected, onClick, emoji, children, tone, small }) {
  return (
    <button
      className={"chip" + (selected ? " is-sel" : "") + (tone === "sensitive" ? " is-sensitive" : "") + (small ? " is-small" : "")}
      onClick={onClick}
    >
      {emoji ? <span className="chip-emoji">{emoji}</span> : null}
      <span>{children}</span>
    </button>
  );
}

// Selectable row card with emoji + label + optional sub + check/radio
function OptionCard({ selected, emoji, label, sub, onClick, multi, accent }) {
  return (
    <button className={"opt" + (selected ? " is-sel" : "")} onClick={onClick}
      style={accent && selected ? { borderColor: accent, boxShadow: `0 0 0 2px ${accent}` } : null}>
      {emoji ? <span className="opt-emoji">{emoji}</span> : null}
      <span className="opt-text">
        <span className="opt-label">{label}</span>
        {sub ? <span className="opt-sub">{sub}</span> : null}
      </span>
      <span className={"opt-mark" + (multi ? " is-check" : "")}>
        {selected ? (
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/></svg>
        ) : null}
      </span>
    </button>
  );
}

// 2–4 option segmented control
function Segmented({ options, value, onChange }) {
  return (
    <div className="seg" style={{ gridTemplateColumns: `repeat(${options.length}, 1fr)` }}>
      {options.map((o) => (
        <button key={o.id} className={"seg-btn" + (value === o.id ? " is-sel" : "")} onClick={() => onChange(o.id)}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

function Primary({ children, onClick, disabled }) {
  return <button className="btn-primary" onClick={onClick} disabled={disabled}>{children}</button>;
}
function Ghost({ children, onClick }) {
  return <button className="btn-ghost" onClick={onClick}>{children}</button>;
}

// A pill toggle (for privacy switches etc.)
function Toggle({ on, onClick, label, sub }) {
  return (
    <button className="togglerow" onClick={onClick}>
      <span className="opt-text">
        <span className="opt-label">{label}</span>
        {sub ? <span className="opt-sub">{sub}</span> : null}
      </span>
      <span className={"switch" + (on ? " is-on" : "")}><span className="switch-knob" /></span>
    </button>
  );
}

Object.assign(window, {
  StatusBar, NavBar, Eyebrow, Logo, Title, Sub, SectionLabel,
  Chip, OptionCard, Segmented, Primary, Ghost, Toggle,
});
