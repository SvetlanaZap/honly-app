// HOnly onboarding — screens 7–11 (rhythm → done) + flirt demo
const { useState: useStateE } = React;

// ── 7 Rhythm + off-limits (optional) ──────────────────────────────
function RhythmScreen({ st, set, next, skip }) {
  const toggleOff = (o) => {
    const has = st.offlimits.includes(o);
    set({ offlimits: has ? st.offlimits.filter((x) => x !== o) : [...st.offlimits, o] });
  };
  return (
    <>
      <Body>
        <Eyebrow>How you chat</Eyebrow>
        <Title>A couple of things that help us match you.</Title>
        <Sub>Optional — skip anytime.</Sub>
        <SectionLabel>How do you like to chat?</SectionLabel>
        <div className="stack">
          {RHYTHM.map((r) => (
            <OptionCard key={r.id} emoji={r.emoji} label={r.label}
              selected={st.rhythm === r.id} onClick={() => set({ rhythm: r.id })} />
          ))}
        </div>
        <SectionLabel hint="🔒 Only you see this">Anything you'd rather not talk about?</SectionLabel>
        <div className="chips">
          {OFFLIMITS.map((o) => (
            <Chip key={o} selected={st.offlimits.includes(o)} onClick={() => toggleOff(o)}>{o}</Chip>
          ))}
        </div>
        <p className="finehint">We quietly steer matches away — your off-limits list is private.</p>
      </Body>
      <Footer>
        <div className="footer-2">
          <Ghost onClick={skip}>Skip</Ghost>
          <Primary onClick={next}>Save & continue</Primary>
        </div>
      </Footer>
    </>
  );
}

// ── 8 Languages (optional) ────────────────────────────────────────
function LangsScreen({ st, set, next, skip }) {
  const [adding, setAdding] = useStateE(false);
  const added = st.langs;
  const addLang = (l) => { if (!added.find((x) => x.lang === l)) set({ langs: [...added, { lang: l, role: "native" }] }); setAdding(false); };
  const setRole = (l, role) => set({ langs: added.map((x) => x.lang === l ? { ...x, role } : x) });
  const remove = (l) => set({ langs: added.filter((x) => x.lang !== l) });
  const avail = LANGUAGES.filter((l) => !added.find((x) => x.lang === l));
  return (
    <>
      <Body>
        <Eyebrow>Languages</Eyebrow>
        <Title>Speak, practice, or just connect in.</Title>
        <Sub>For each language, pick what you want. Optional.</Sub>
        <div className="stack">
          {added.map((x) => (
            <div key={x.lang} className="langrow">
              <div className="langrow-top">
                <span className="langrow-name">{x.lang}</span>
                <button className="langrow-x" onClick={() => remove(x.lang)} aria-label="Remove">✕</button>
              </div>
              <div className="seg seg--lang" style={{ gridTemplateColumns: "repeat(3,1fr)" }}>
                {LANG_ROLES.map((r) => (
                  <button key={r.id} className={"seg-btn" + (x.role === r.id ? " is-sel" : "")} onClick={() => setRole(x.lang, r.id)}>
                    <span className="seg-emoji">{r.emoji}</span>{r.label}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
        {adding ? (
          <div className="chips chips--pick">
            {avail.map((l) => <Chip key={l} small onClick={() => addLang(l)}>{l}</Chip>)}
          </div>
        ) : (
          <button className="addlang" onClick={() => setAdding(true)} disabled={avail.length === 0}>+ Add language</button>
        )}
        <p className="finehint">“Love chatting with speakers” pairs you with others who'd rather talk in that language — about belonging, never nationality.</p>
      </Body>
      <Footer>
        <div className="footer-2">
          <Ghost onClick={skip}>Skip</Ghost>
          <Primary onClick={next}>Save & continue</Primary>
        </div>
      </Footer>
    </>
  );
}

// ── 9 About you (optional) ────────────────────────────────────────
function VisEye({ note }) { return <span className="viseye">👁 {note || "Matches"}</span>; }

function AboutScreen({ st, set, next, skip }) {
  const toggleCulture = (c) => {
    const has = st.cultures.includes(c);
    set({ cultures: has ? st.cultures.filter((x) => x !== c) : [...st.cultures, c] });
  };
  const CULTURES = ["Japanese","Italian","Brazilian","Nigerian","Indian","Mexican","French","Korean","Turkish"];
  return (
    <>
      <Body>
        <Eyebrow>About you</Eyebrow>
        <Title>A little about you.</Title>
        <Sub>Share only what you want — every field is optional, with its own visibility.</Sub>

        <SectionLabel hint="Shows on your preview · editable anytime">Today's vibe</SectionLabel>
        <div className="chips">
          {VIBES.map((v) => (
            <Chip key={v.id} emoji={v.emoji} selected={st.vibe === v.id}
              onClick={() => set({ vibe: st.vibe === v.id ? null : v.id })}>{v.label}</Chip>
          ))}
        </div>

        <SectionLabel hint={<VisEye note="Matches" />}>Avatar or photo</SectionLabel>
        <div className="avatars">
          <button className="av-upload">＋<span>Upload</span></button>
          {AVATARS.map((a) => (
            <button key={a} className={"av" + (st.avatar === a ? " is-sel" : "")}
              onClick={() => set({ avatar: st.avatar === a ? null : a })}>{a}</button>
          ))}
        </div>
        <p className="finehint">An avatar is fully equal to a photo. We never nudge you toward a face.</p>

        <SectionLabel hint={<VisEye />}>Age</SectionLabel>
        <div className="chips">
          {AGES.map((a) => <Chip key={a} small selected={st.ageRange === a} onClick={() => set({ ageRange: st.ageRange === a ? null : a })}>{a}</Chip>)}
        </div>

        <SectionLabel hint={<VisEye />}>Gender</SectionLabel>
        <div className="chips">
          {GENDERS.map((g) => <Chip key={g} small selected={st.gender === g} onClick={() => set({ gender: st.gender === g ? null : g })}>{g}</Chip>)}
        </div>

        <SectionLabel hint={<VisEye note="Hidden" />}>Location · off by default</SectionLabel>
        <div className="stack">
          {LOCATION.map((l) => (
            <OptionCard key={l.id} label={l.label} sub={l.sub}
              selected={st.location === l.id} onClick={() => set({ location: l.id })} />
          ))}
        </div>

        <SectionLabel>Open to meeting eventually?</SectionLabel>
        <div className="stack">
          {MEETING.map((m) => (
            <OptionCard key={m.id} emoji={m.emoji} label={m.label}
              selected={st.meeting === m.id} onClick={() => set({ meeting: st.meeting === m.id ? null : m.id })} />
          ))}
        </div>
        <p className="finehint">HOnly never pressures anyone to meet. If you do, meet in public and tell a friend.</p>

        <SectionLabel hint={<VisEye />}>Cultures you love sharing or learning about</SectionLabel>
        <div className="chips">
          {CULTURES.map((c) => <Chip key={c} small selected={st.cultures.includes(c)} onClick={() => toggleCulture(c)}>{c}</Chip>)}
        </div>
      </Body>
      <Footer>
        <div className="footer-2">
          <Ghost onClick={skip}>Skip for now</Ghost>
          <Primary onClick={next}>Finish</Primary>
        </div>
      </Footer>
    </>
  );
}

// ── 10 Human pledge ───────────────────────────────────────────────
function PledgeScreen({ st, set, next }) {
  return (
    <>
      <Body>
        <Eyebrow>The HOnly part</Eyebrow>
        <Title>One last thing.</Title>
        <Sub>Everyone here agrees to be a real human, here in good faith. That's the whole deal.</Sub>
        <div className="pledge-card">
          <div className="pledge-mark">🤝</div>
          <OptionCard selected={st.pledge} label="I'm a real person"
            sub="…and I'll treat others like real people." onClick={() => set({ pledge: !st.pledge })} />
        </div>
      </Body>
      <Footer>
        <Primary onClick={next} disabled={!st.pledge}>Enter HOnly</Primary>
      </Footer>
    </>
  );
}

// ── 11 Done ───────────────────────────────────────────────────────
function topInterestLabels(st, n) {
  const out = [];
  for (const t of TAXONOMY) {
    if (st.topics[t.id]) out.push({ emoji: t.emoji, label: t.label });
    if (out.length >= n) break;
  }
  return out;
}
function completion(st) {
  let score = 0, total = 9;
  if (st.name.trim()) score++;
  if (st.intent.length) score++;
  if (st.depth) score++;
  if (Object.keys(st.topics).length >= 3) score++;
  if (st.flirt) score++;
  if (st.rhythm) score++;
  if (st.langs.length) score++;
  if (st.vibe || st.avatar || st.ageRange || st.gender) score++;
  if (st.pledge) score++;
  return Math.round((score / total) * 100);
}

function DoneScreen({ st, go }) {
  const vibe = VIBES.find((v) => v.id === st.vibe);
  const top = topInterestLabels(st, 4);
  const pct = completion(st);
  return (
    <div className="screen screen--done">
      <div className="screen-body done-body">
        <div className="done-burst">🎉</div>
        <Eyebrow>You're in</Eyebrow>
        <h1 className="title done-title">Welcome to HOnly{st.name ? ", " + st.name : ""}!</h1>
        <p className="sub">You're part of a community of real humans having real conversations.</p>

        <div className="preview-card">
          <div className="pc-top">
            <div className="pc-av">{st.avatar || "🙂"}</div>
            <div className="pc-id">
              <div className="pc-name">{st.name || "You"}{st.ageRange && st.ageRange !== "Prefer not to say" ? <span className="pc-age">, {st.ageRange}</span> : null}</div>
              {vibe ? <div className="pc-vibe">{vibe.emoji} {vibe.label}</div> : <div className="pc-vibe pc-vibe--add">+ set today's vibe</div>}
            </div>
            <div className="pc-pct"><b>{pct}%</b><span>complete</span></div>
          </div>
          {top.length ? (
            <div className="pc-chips">
              {top.map((t) => <span key={t.label} className="pc-chip">{t.emoji} {t.label}</span>)}
            </div>
          ) : null}
        </div>
      </div>

      <div className="screen-footer">
        <Primary onClick={() => go("explore")}>Start exploring →</Primary>
        <p className="finehint center">Add more anytime for better matches — never a wall.</p>
      </div>
    </div>
  );
}

// ── Flirt mutual-indicator demo (after onboarding) ────────────────
function ExploreDemo({ st, go, restart }) {
  const flirtOn = st.flirt === "open" || st.flirt === "mutual";
  const shared = topInterestLabels(st, 3);
  const sharedLabels = shared.length ? shared : [{ emoji: "✨", label: "AI" }, { emoji: "🎬", label: "Film" }];
  return (
    <div className="screen screen--demo">
      <Body>
        <div className="demo-eyebrow">DISCOVER · A FIRST MATCH</div>
        <h1 className="title demo-title">Here's how a match feels.</h1>
        <Sub>No swiping — a curated person you choose to learn about.</Sub>

        <div className="match-card">
          <div className="mc-head">
            <div className="mc-av">🦜</div>
            <div className="mc-id">
              <div className="mc-name">Maya, 27 <span className="mc-verif">✓</span></div>
              <div className="mc-meta">🟢 Online · 😌 Mellow today</div>
            </div>
            <div className="mc-pct">92%</div>
          </div>

          {flirtOn ? (
            <div className="flirt-indicator">
              <span className="fi-spark">✨</span>
              <span>You're <b>both open to a little flirting</b> — playful is welcome. No obligation, fully reversible.</span>
            </div>
          ) : (
            <div className="flirt-indicator fi--platonic">
              <span className="fi-spark">🛡️</span>
              <span>Kept <b>platonic</b> — your boundary travels with you. Flirting is never enabled here.</span>
            </div>
          )}

          <div className="mc-section">WHY YOU MATCH</div>
          <div className="chips">
            {sharedLabels.map((s) => <span key={s.label} className="pc-chip">{s.emoji} {s.label}</span>)}
            <span className="pc-chip">🗣️ English</span>
          </div>

          <button className="btn-primary mc-cta">💬 Start conversation</button>
        </div>

        <div className="mech-note">
          <div className="mech-title">How “open to flirting” works</div>
          <ul>
            <li>Enabled <b>only if both</b> people opted in — one person's yes can't reach an unwilling other.</li>
            <li>It's <b>permission, not a script</b>: a subtle shared note, never a separate “flirt zone.”</li>
            <li>Switch to platonic anytime — it updates instantly and is always respected.</li>
            <li>Never unlocks location or contact info. Still not a dating app.</li>
          </ul>
        </div>
      </Body>
      <Footer>
        <Ghost onClick={restart}>↺ Restart onboarding</Ghost>
      </Footer>
    </div>
  );
}

Object.assign(window, {
  RhythmScreen, LangsScreen, AboutScreen, PledgeScreen, DoneScreen, ExploreDemo, completion,
});
