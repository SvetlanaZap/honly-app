// HOnly onboarding — app shell (state, navigation, persistence, tweaks)
const { useState: useStateA, useEffect: useEffectA } = React;

const STORE_KEY = "honly_onboarding_v1";
const NAV_KEYS = FLOW.filter((f) => f.key !== "welcome" && f.key !== "done").map((f) => f.key);

const INITIAL = {
  age18: false, name: "", intent: [], depth: null, topics: {}, flirt: null,
  rhythm: null, offlimits: [], langs: [], vibe: null, avatar: null,
  ageRange: null, gender: null, location: "none", meeting: null, cultures: [], pledge: false,
};

// Rich demo state so populated screens (interests, about, done, discover) export fully
const DEMO_STATE = {
  age18: true, name: "Alex", intent: ["deep", "friends"], depth: "both",
  topics: {
    science: ["AI", "Space", "Psychology"],
    music: ["Indie", "Concerts & live"],
    travel: ["Living abroad", "Food travel"],
    family: ["Friendship", "Long-distance"],
  },
  flirt: "mutual", rhythm: "slow", offlimits: ["Politics", "Work"],
  langs: [{ lang: "English", role: "native" }, { lang: "Portuguese", role: "connect" }],
  vibe: "reflect", avatar: "🦉", ageRange: "25–34", gender: "Non-binary",
  location: "city", meeting: "maybe", cultures: ["Japanese", "Brazilian"], pledge: true,
};

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "interestsStyle": "inline",
  "primary": "#E8654A",
  "displayFont": "Bricolage Grotesque"
}/*EDITMODE-END*/;

function loadSaved() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (e) { return null; }
}

function App() {
  const THEME = (typeof window !== "undefined" && window.__HONLY_THEME) || "dark";
  const isLight = THEME === "light";
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const saved = React.useMemo(loadSaved, []);
  const [view, setView] = useStateA(saved && saved.view ? saved.view : "welcome");
  const [st, setSt] = useStateA(saved && saved.st ? { ...INITIAL, ...saved.st } : INITIAL);

  useEffectA(() => {
    try { localStorage.setItem(STORE_KEY, JSON.stringify({ view, st })); } catch (e) {}
  }, [view, st]);

  // Export hook: step through screens (and optionally seed a full demo state) from gen_pptx showJs
  useEffectA(() => {
    window.__honlyShow = (v, seed) => {
      if (seed) setSt((s) => ({ ...s, ...DEMO_STATE }));
      setView(v);
    };
  }, []);

  const set = (patch) => setSt((s) => ({ ...s, ...patch }));

  const flowIndex = FLOW.findIndex((f) => f.key === view);
  const go = (key) => { setView(key); const b = document.querySelector(".screen-body"); if (b) b.scrollTop = 0; };
  const next = () => {
    if (view === "explore") return;
    const i = FLOW.findIndex((f) => f.key === view);
    if (i < FLOW.length - 1) go(FLOW[i + 1].key);
  };
  const back = () => {
    if (view === "explore") { go("done"); return; }
    if (view === "signin") { go("welcome"); return; }
    const i = FLOW.findIndex((f) => f.key === view);
    if (i > 0) go(FLOW[i - 1].key);
  };
  const restart = () => { setSt(INITIAL); go("welcome"); };

  const showNav = view !== "welcome" && view !== "signin" && view !== "done" && view !== "explore";
  const step = NAV_KEYS.indexOf(view) + 1;

  let screen = null;
  const props = { st, set, next, skip: next, tweaks, go, restart };
  switch (view) {
    case "welcome":   screen = <WelcomeScreen {...props} />; break;
    case "signin":    screen = <SignInScreen {...props} />; break;
    case "age":       screen = <AgeScreen {...props} />; break;
    case "name":      screen = <NameScreen {...props} />; break;
    case "intent":    screen = <IntentScreen {...props} />; break;
    case "depth":     screen = <DepthScreen {...props} />; break;
    case "interests": screen = <InterestsScreen {...props} />; break;
    case "flirt":     screen = <FlirtScreen {...props} />; break;
    case "rhythm":    screen = <RhythmScreen {...props} />; break;
    case "langs":     screen = <LangsScreen {...props} />; break;
    case "about":     screen = <AboutScreen {...props} />; break;
    case "pledge":    screen = <PledgeScreen {...props} />; break;
    case "done":      screen = <DoneScreen {...props} />; break;
    case "explore":   screen = <ExploreDemo {...props} />; break;
    default:          screen = <WelcomeScreen {...props} />;
  }

  const fontMap = isLight ? {
    "Space Grotesk": "'Space Grotesk', sans-serif",
    "Sora": "'Sora', sans-serif",
    "Fraunces": "'Fraunces', serif",
  } : {
    "Bricolage Grotesque": "'Bricolage Grotesque', sans-serif",
    "Plus Jakarta Sans": "'Plus Jakarta Sans', sans-serif",
    "Fraunces": "'Fraunces', serif",
  };
  const defaultDisplay = isLight ? "Space Grotesk" : "Bricolage Grotesque";
  const fontOptions = isLight
    ? ["Space Grotesk", "Sora", "Fraunces"]
    : ["Bricolage Grotesque", "Plus Jakarta Sans", "Fraunces"];
  const displayChoice = fontMap[tweaks.displayFont] ? tweaks.displayFont : defaultDisplay;
  const rootStyle = {
    "--coral": tweaks.primary,
    "--display": fontMap[displayChoice],
  };

  return (
    <div className="phone" style={rootStyle} data-screen-label={"Screen: " + view}>
      <div className="phone-inner">
        <StatusBar />
        {showNav ? <NavBar onBack={back} step={step} total={NAV_KEYS.length} canBack={flowIndex > 0} dots={isLight} /> : null}
        <div className={"screen-wrap" + (showNav ? "" : " no-nav")}>
          {screen}
        </div>
      </div>

      <TweaksPanel>
        <TweakSection label="Screen 5 · Interests engine" />
        <TweakRadio label="Treatment" value={tweaks.interestsStyle}
          options={["inline", "sheet"]} onChange={(v) => setTweak("interestsStyle", v)} />
        <p className="tweak-note">“inline” expands sub-topics in an accordion; “sheet” opens a bottom sheet. Try it on Screen 5.</p>
        <TweakSection label="Brand" />
        <TweakColor label="Primary" value={tweaks.primary}
          options={["#E8654A", "#3CBEA8", "#1B2532", "#C9527A", "#E0A53C"]}
          onChange={(v) => setTweak("primary", v)} />
        <TweakSelect label="Display font" value={displayChoice}
          options={fontOptions}
          onChange={(v) => setTweak("displayFont", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
